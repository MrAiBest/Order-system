import { useState, useEffect, useCallback } from 'react';

// Import notification store
import { useNotifications } from './useNotifications';

export interface Client {
  id: string;
  name: string;
  location: string;
  phone: string;
  email?: string;
  totalPurchases: number;
  lastOrderDate?: string;
  createdDate: string;
  orders: string[]; // Order IDs
}

export interface Employee {
  id: string;
  name: string;
  role: 'Driver' | 'Salesperson' | 'Manager' | 'Admin' | 'Clerk' | 'Delivery Worker';
  salary: number;
  phone: string;
  email?: string;
  hireDate: string;
  workDone: string[];
  isActive: boolean;
}

export interface PaymentMethod {
  type: 'cash' | 'transfer' | 'credit' | 'debit';
  amount: number;
  reference?: string;
  timestamp: string;
}

export interface DeliveryStatus {
  orderId: number;
  status: 'pending' | 'in_transit' | 'delivered' | 'returned' | 'damaged';
  deliveryPerson?: string;
  deliveryDate?: string;
  returnReason?: string;
  damageDescription?: string;
  deliveryNotes?: string;
  timestamp: string;
}

export interface DaybookEntry {
  id: string;
  timestamp: string;
  action: string;
  category: 'order' | 'inventory' | 'bill' | 'client' | 'employee' | 'delivery';
  description: string;
  userId: string;
  userName: string;
  details?: any;
}

// Simulated real-time data store (in production, this would connect to a backend)
class DataStore {
  private static instance: DataStore;
  private subscribers: Set<() => void> = new Set();
  private notificationCallbacks: Set<(type: string, message: string, title: string) => void> = new Set();
  
  // Initial data
  private data = {
    inventory: [
      { 
        id: 1, 
        name: 'Sugar (50kg bags)', 
        category: 'Foodstuffs', 
        current: 45, 
        minimum: 20, 
        price: 125.00, 
        status: 'In Stock',
        supplier: 'Sweet Supplies Ltd'
      },
      { 
        id: 2, 
        name: 'Wheat Flour (25kg)', 
        category: 'Foodstuffs', 
        current: 8, 
        minimum: 15, 
        price: 85.50, 
        status: 'Low Stock',
        supplier: 'Grain Masters'
      },
      { 
        id: 3, 
        name: 'Cooking Oil (20L)', 
        category: 'Foodstuffs', 
        current: 22, 
        minimum: 10, 
        price: 95.00, 
        status: 'In Stock',
        supplier: 'Oil Express'
      },
      { 
        id: 4, 
        name: 'Laundry Soap (200g)', 
        category: 'Household', 
        current: 0, 
        minimum: 50, 
        price: 15.75, 
        status: 'Out of Stock',
        supplier: 'Clean & Fresh Co'
      },
      { 
        id: 5, 
        name: 'Sanitary Towels (Pack of 10)', 
        category: 'Household', 
        current: 35, 
        minimum: 25, 
        price: 45.00, 
        status: 'In Stock',
        supplier: 'Health Care Plus'
      },
      { 
        id: 6, 
        name: 'Rice (25kg bags)', 
        category: 'Foodstuffs', 
        current: 18, 
        minimum: 12, 
        price: 110.00, 
        status: 'In Stock',
        supplier: 'Rice Valley'
      }
    ],
    orders: [
      {
        id: 1,
        customer: 'Sunshine Supermarket',
        location: 'Downtown District',
        phone: '+1-555-0123',
        items: [
          { name: 'Sugar (50kg bags)', quantity: 10, price: 125.00 },
          { name: 'Rice (25kg bags)', quantity: 5, price: 110.00 }
        ],
        total: 1800.00,
        status: 'Processing',
        priority: 'High',
        orderDate: '2024-06-03',
        expectedDelivery: '2024-06-05',
        salesperson: 'David Sales',
        payment: {
          type: 'credit' as const,
          amount: 1800.00,
          timestamp: new Date().toISOString()
        }
      }
    ],
    bills: [
      {
        id: 'BILL-001',
        description: 'Office Rent - June 2024',
        category: 'Rent',
        amount: 2500.00,
        dueDate: '2024-06-10',
        status: 'Pending',
        priority: 'High',
        vendor: 'PropertyCorp Ltd',
        issueDate: '2024-06-01'
      },
      {
        id: 'BILL-002',
        description: 'Internet & Phone Services',
        category: 'Utilities',
        amount: 180.50,
        dueDate: '2024-06-15',
        status: 'Paid',
        priority: 'Medium',
        vendor: 'TeleConnect Inc',
        issueDate: '2024-05-30',
        paidDate: '2024-06-02'
      },
      {
        id: 'BILL-003',
        description: 'Staff Salaries - May 2024',
        category: 'Payroll',
        amount: 12500.00,
        dueDate: '2024-06-05',
        status: 'Overdue',
        priority: 'High',
        vendor: 'Internal Payroll',
        issueDate: '2024-05-31'
      },
      {
        id: 'BILL-004',
        description: 'Office Supplies',
        category: 'Supplies',
        amount: 145.75,
        dueDate: '2024-06-20',
        status: 'Pending',
        priority: 'Low',
        vendor: 'Office Depot',
        issueDate: '2024-06-02'
      },
      {
        id: 'BILL-005',
        description: 'Vehicle Fuel & Maintenance',
        category: 'Transportation',
        amount: 450.00,
        dueDate: '2024-06-12',
        status: 'Pending',
        priority: 'Medium',
        vendor: 'AutoCare Services',
        issueDate: '2024-06-01'
      }
    ],
    clients: [
      {
        id: 'CLIENT-001',
        name: 'Sunshine Supermarket',
        location: 'Downtown District',
        phone: '+1-555-0123',
        email: 'orders@sunshinesuper.com',
        totalPurchases: 1800.00,
        lastOrderDate: '2024-06-03',
        createdDate: '2024-01-15',
        orders: ['1']
      }
    ] as Client[],
    employees: [
      {
        id: 'EMP-001',
        name: 'David Sales',
        role: 'Salesperson' as const,
        salary: 3500.00,
        phone: '+1-555-0001',
        email: 'david@company.com',
        hireDate: '2024-01-15',
        workDone: ['Order processing', 'Client management'],
        isActive: true
      },
      {
        id: 'EMP-002',
        name: 'Mike Driver',
        role: 'Driver' as const,
        salary: 2800.00,
        phone: '+1-555-0002',
        email: 'mike@company.com',
        hireDate: '2024-02-01',
        workDone: ['Deliveries', 'Vehicle maintenance'],
        isActive: true
      },
      {
        id: 'EMP-003',
        name: 'Sarah Manager',
        role: 'Manager' as const,
        salary: 5500.00,
        phone: '+1-555-0003',
        email: 'sarah@company.com',
        hireDate: '2023-12-01',
        workDone: ['Team management', 'Strategic planning'],
        isActive: true
      }
    ] as Employee[],
    deliveries: [] as DeliveryStatus[],
    daybook: [] as DaybookEntry[]
  };

  static getInstance() {
    if (!DataStore.instance) {
      DataStore.instance = new DataStore();
    }
    return DataStore.instance;
  }

  subscribe(callback: () => void) {
    this.subscribers.add(callback);
    return () => {
      this.subscribers.delete(callback);
    };
  }

  subscribeToNotifications(callback: (type: string, message: string, title: string) => void) {
    this.notificationCallbacks.add(callback);
    return () => {
      this.notificationCallbacks.delete(callback);
    };
  }

  private notify() {
    this.subscribers.forEach(callback => callback());
  }

  private notifyAction(type: string, title: string, message: string) {
    this.notificationCallbacks.forEach(callback => callback(type, title, message));
  }

  private addDaybookEntry(action: string, category: DaybookEntry['category'], description: string, userId: string, userName: string, details?: any) {
    const entry: DaybookEntry = {
      id: `DAY-${Date.now()}`,
      timestamp: new Date().toISOString(),
      action,
      category,
      description,
      userId,
      userName,
      details
    };
    this.data.daybook.unshift(entry);
    
    // Keep only last 1000 entries
    if (this.data.daybook.length > 1000) {
      this.data.daybook = this.data.daybook.slice(0, 1000);
    }
  }

  // Analytics methods
  getAnalyticsData() {
    const now = new Date();
    const sixMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 6, 1);
    
    // Generate monthly data based on actual orders
    const monthlyData = [];
    for (let i = 5; i >= 0; i--) {
      const month = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthName = month.toLocaleDateString('en-US', { month: 'short' });
      
      // Calculate actual data from orders for this month
      const monthOrders = this.data.orders.filter(order => {
        const orderDate = new Date(order.orderDate);
        return orderDate.getMonth() === month.getMonth() && orderDate.getFullYear() === month.getFullYear();
      });
      
      const revenue = monthOrders.reduce((sum, order) => sum + order.total, 0);
      const orders = monthOrders.length;
      const customers = new Set(monthOrders.map(order => order.customer)).size;
      
      monthlyData.push({
        month: monthName,
        revenue: revenue || (Math.random() * 20000 + 40000), // Fallback to random for demo
        orders: orders || Math.floor(Math.random() * 50 + 100),
        customers: customers || Math.floor(Math.random() * 30 + 70)
      });
    }

    // Product performance based on actual inventory and orders
    const productData = this.data.inventory.map(product => ({
      name: product.name,
      sales: Math.floor(Math.random() * 200 + 100),
      revenue: Math.floor(Math.random() * 20000 + 10000),
      color: ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'][Math.floor(Math.random() * 6)]
    }));

    // Daily sales for current week
    const dailySales = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => ({
      day,
      sales: Math.floor(Math.random() * 15000 + 8000)
    }));

    return {
      monthlyData,
      productData,
      dailySales,
      totalRevenue: monthlyData.reduce((sum, item) => sum + item.revenue, 0),
      totalOrders: monthlyData.reduce((sum, item) => sum + item.orders, 0),
      totalCustomers: this.data.clients.length,
      activeEmployees: this.data.employees.filter(emp => emp.isActive).length
    };
  }

  // Inventory methods
  getInventory() {
    return [...this.data.inventory];
  }

  addProduct(product: any, userId: string = 'SYSTEM', userName: string = 'System') {
    const newProduct = {
      ...product,
      id: this.data.inventory.length + 1,
      status: product.current === 0 ? 'Out of Stock' : 
              product.current < product.minimum ? 'Low Stock' : 'In Stock'
    };
    this.data.inventory.push(newProduct);
    this.addDaybookEntry('ADD_PRODUCT', 'inventory', `Added new product: ${newProduct.name}`, userId, userName, newProduct);
    this.notify();
    this.notifyAction('product', 'New Product Added', `${newProduct.name} has been added to inventory`);
    console.log('Product added to store:', newProduct);
  }

  restockProduct(productId: number, quantity: number, userId: string = 'SYSTEM', userName: string = 'System') {
    const product = this.data.inventory.find(p => p.id === productId);
    if (product) {
      const oldStock = product.current;
      product.current += quantity;
      product.status = product.current === 0 ? 'Out of Stock' : 
                      product.current < product.minimum ? 'Low Stock' : 'In Stock';
      this.addDaybookEntry('RESTOCK', 'inventory', `Restocked ${product.name}: ${oldStock} → ${product.current} units`, userId, userName, { productId, oldStock, newStock: product.current, quantity });
      this.notify();
      this.notifyAction('restock', 'Product Restocked', `${product.name} restocked: ${oldStock} → ${product.current} units`);
      console.log(`Product ${productId} restocked with ${quantity} units`);
    }
  }

  updateInventoryFromOrder(orderItems: any[]) {
    orderItems.forEach(item => {
      const product = this.data.inventory.find(p => p.name === item.name);
      if (product && product.current >= item.quantity) {
        product.current -= item.quantity;
        product.status = product.current === 0 ? 'Out of Stock' : 
                        product.current < product.minimum ? 'Low Stock' : 'In Stock';
      }
    });
    this.notify();
  }

  // Orders methods
  getOrders() {
    return [...this.data.orders];
  }

  addOrder(order: any, userId: string = 'SYSTEM', userName: string = 'System') {
    const newOrder = {
      ...order,
      id: this.data.orders.length + 1
    };
    this.data.orders.push(newOrder);
    
    // Create or update client automatically
    this.createOrUpdateClient(order);
    
    // Update inventory based on order
    this.updateInventoryFromOrder(order.items);
    
    this.addDaybookEntry('ADD_ORDER', 'order', `New order #${newOrder.id} from ${newOrder.customer} - $${newOrder.total.toFixed(2)}`, userId, userName, newOrder);
    this.notify();
    this.notifyAction('order', 'New Order Added', `Order #${newOrder.id} from ${newOrder.customer} - $${newOrder.total.toFixed(2)}`);
    console.log('Order added to store:', newOrder);
  }

  updateOrderStatus(orderId: number, status: string, userId: string = 'SYSTEM', userName: string = 'System') {
    const order = this.data.orders.find(o => o.id === orderId);
    if (order) {
      const oldStatus = order.status;
      order.status = status;
      this.addDaybookEntry('UPDATE_ORDER_STATUS', 'order', `Order #${orderId} status changed: ${oldStatus} → ${status}`, userId, userName, { orderId, oldStatus, newStatus: status });
      this.notify();
      this.notifyAction('order', 'Order Status Updated', `Order #${orderId} status changed: ${oldStatus} → ${status}`);
      console.log(`Order ${orderId} status updated to: ${status}`);
    }
  }

  // Bills methods
  getBills() {
    return [...this.data.bills];
  }

  addBill(bill: any, userId: string = 'SYSTEM', userName: string = 'System') {
    const newBill = {
      ...bill,
      id: `BILL-${String(this.data.bills.length + 1).padStart(3, '0')}`
    };
    this.data.bills.push(newBill);
    this.addDaybookEntry('ADD_BILL', 'bill', `New bill: ${newBill.description} - $${newBill.amount.toFixed(2)}`, userId, userName, newBill);
    this.notify();
    this.notifyAction('bill', 'New Bill Added', `${newBill.description} - $${newBill.amount.toFixed(2)} due ${newBill.dueDate}`);
    console.log('Bill added to store:', newBill);
  }

  updateBillStatus(billId: string, status: string, paidDate?: string, userId: string = 'SYSTEM', userName: string = 'System') {
    const bill = this.data.bills.find(b => b.id === billId);
    if (bill) {
      const oldStatus = bill.status;
      bill.status = status;
      if (paidDate) {
        bill.paidDate = paidDate;
      }
      this.addDaybookEntry('UPDATE_BILL_STATUS', 'bill', `Bill ${bill.description} status changed: ${oldStatus} → ${status}`, userId, userName, { billId, oldStatus, newStatus: status, paidDate });
      this.notify();
      this.notifyAction('bill', 'Bill Status Updated', `${bill.description} - Status changed: ${oldStatus} → ${status}`);
      console.log(`Bill ${billId} status updated to: ${status}`);
    }
  }

  // Clients methods
  getClients() {
    return [...this.data.clients];
  }

  createOrUpdateClient(orderData: any) {
    const existingClient = this.data.clients.find(c => 
      c.name === orderData.customer && c.phone === orderData.phone
    );

    if (existingClient) {
      // Update existing client
      existingClient.totalPurchases += orderData.total;
      existingClient.lastOrderDate = orderData.orderDate;
      existingClient.orders.push(orderData.id?.toString() || (this.data.orders.length + 1).toString());
    } else {
      // Create new client
      const newClient: Client = {
        id: `CLIENT-${String(this.data.clients.length + 1).padStart(3, '0')}`,
        name: orderData.customer,
        location: orderData.location,
        phone: orderData.phone,
        email: orderData.email || '',
        totalPurchases: orderData.total,
        lastOrderDate: orderData.orderDate,
        createdDate: new Date().toISOString().split('T')[0],
        orders: [orderData.id?.toString() || (this.data.orders.length + 1).toString()]
      };
      this.data.clients.push(newClient);
      this.notifyAction('client', 'New Client Created', `${newClient.name} added to client database`);
    }
  }

  addClient(clientData: Omit<Client, 'id' | 'createdDate' | 'orders'>, userId: string = 'SYSTEM', userName: string = 'System') {
    const newClient: Client = {
      ...clientData,
      id: `CLIENT-${String(this.data.clients.length + 1).padStart(3, '0')}`,
      createdDate: new Date().toISOString().split('T')[0],
      orders: []
    };
    this.data.clients.push(newClient);
    this.addDaybookEntry('ADD_CLIENT', 'client', `New client added: ${newClient.name}`, userId, userName, newClient);
    this.notify();
    this.notifyAction('client', 'Client Added', `${newClient.name} manually added to client database`);
    console.log('Client added:', newClient);
  }

  // Employees methods
  getEmployees() {
    return [...this.data.employees];
  }

  addEmployee(employeeData: Omit<Employee, 'id'>, userId: string = 'SYSTEM', userName: string = 'System') {
    const newEmployee: Employee = {
      ...employeeData,
      id: `EMP-${String(this.data.employees.length + 1).padStart(3, '0')}`
    };
    this.data.employees.push(newEmployee);
    this.addDaybookEntry('ADD_EMPLOYEE', 'employee', `New employee added: ${newEmployee.name} (${newEmployee.role})`, userId, userName, newEmployee);
    this.notify();
    this.notifyAction('employee', 'Employee Added', `${newEmployee.name} (${newEmployee.role}) added to team`);
    console.log('Employee added:', newEmployee);
  }

  updateEmployee(employeeId: string, updates: Partial<Employee>, userId: string = 'SYSTEM', userName: string = 'System') {
    const employee = this.data.employees.find(e => e.id === employeeId);
    if (employee) {
      const oldData = { ...employee };
      Object.assign(employee, updates);
      this.addDaybookEntry('UPDATE_EMPLOYEE', 'employee', `Employee updated: ${employee.name}`, userId, userName, { employeeId, oldData, updates });
      this.notify();
      this.notifyAction('employee', 'Employee Updated', `${employee.name} information updated`);
      console.log('Employee updated:', employee);
    }
  }

  // Delivery methods
  getDeliveries() {
    return [...this.data.deliveries];
  }

  updateDeliveryStatus(orderId: number, status: DeliveryStatus['status'], deliveryPerson: string, notes?: string, returnReason?: string, damageDescription?: string, userId: string = 'SYSTEM', userName: string = 'System') {
    const existingDelivery = this.data.deliveries.find(d => d.orderId === orderId);
    
    if (existingDelivery) {
      existingDelivery.status = status;
      existingDelivery.deliveryPerson = deliveryPerson;
      existingDelivery.deliveryNotes = notes;
      existingDelivery.returnReason = returnReason;
      existingDelivery.damageDescription = damageDescription;
      existingDelivery.timestamp = new Date().toISOString();
      if (status === 'delivered') {
        existingDelivery.deliveryDate = new Date().toISOString().split('T')[0];
      }
    } else {
      const newDelivery: DeliveryStatus = {
        orderId,
        status,
        deliveryPerson,
        deliveryDate: status === 'delivered' ? new Date().toISOString().split('T')[0] : undefined,
        returnReason,
        damageDescription,
        deliveryNotes: notes,
        timestamp: new Date().toISOString()
      };
      this.data.deliveries.push(newDelivery);
    }

    // Create detailed description based on action
    let description = '';
    switch (status) {
      case 'in_transit':
        description = `Order #${orderId} picked up for delivery by ${deliveryPerson}`;
        break;
      case 'delivered':
        description = `Order #${orderId} successfully delivered by ${deliveryPerson}`;
        break;
      case 'returned':
        description = `Order #${orderId} returned by ${deliveryPerson}${returnReason ? ` (Reason: ${returnReason})` : ''}`;
        break;
      case 'damaged':
        description = `Order #${orderId} reported as damaged by ${deliveryPerson}${damageDescription ? ` (${damageDescription})` : ''}`;
        break;
      default:
        description = `Order #${orderId} delivery status updated to ${status} by ${deliveryPerson}`;
    }

    this.addDaybookEntry('UPDATE_DELIVERY', 'delivery', description, userId, userName, { 
      orderId, 
      status, 
      deliveryPerson, 
      notes, 
      returnReason, 
      damageDescription 
    });

    this.notify();
    this.notifyAction('order', 'Delivery Status Updated', `Order #${orderId} ${status.replace('_', ' ')} by ${deliveryPerson}`);
    console.log(`Delivery updated for order ${orderId}: ${status}`);
  }

  // Daybook methods
  getDaybook() {
    return [...this.data.daybook];
  }

  getDaybookByDate(date: string) {
    return this.data.daybook.filter(entry => entry.timestamp.startsWith(date));
  }

  getDaybookByCategory(category: DaybookEntry['category']) {
    return this.data.daybook.filter(entry => entry.category === category);
  }
}

export const useDataStore = () => {
  const [, forceUpdate] = useState({});
  const store = DataStore.getInstance();
  const { addNotification } = useNotifications();

  useEffect(() => {
    const unsubscribe = store.subscribe(() => {
      forceUpdate({});
    });
    return unsubscribe;
  }, [store]);

  useEffect(() => {
    const unsubscribeNotifications = store.subscribeToNotifications((type, title, message) => {
      addNotification({
        type: type as any,
        title,
        message
      });
    });
    return unsubscribeNotifications;
  }, [store, addNotification]);

  return {
    // Analytics
    getAnalyticsData: store.getAnalyticsData.bind(store),
    
    // Inventory
    inventory: store.getInventory(),
    addProduct: store.addProduct.bind(store),
    restockProduct: store.restockProduct.bind(store),
    
    // Orders
    orders: store.getOrders(),
    addOrder: store.addOrder.bind(store),
    updateOrderStatus: store.updateOrderStatus.bind(store),
    
    // Bills
    bills: store.getBills(),
    addBill: store.addBill.bind(store),
    updateBillStatus: store.updateBillStatus.bind(store),

    // Clients
    clients: store.getClients(),
    addClient: store.addClient.bind(store),

    // Employees
    employees: store.getEmployees(),
    addEmployee: store.addEmployee.bind(store),
    updateEmployee: store.updateEmployee.bind(store),

    // Deliveries
    deliveries: store.getDeliveries(),
    updateDeliveryStatus: store.updateDeliveryStatus.bind(store),

    // Daybook
    daybook: store.getDaybook(),
    getDaybookByDate: store.getDaybookByDate.bind(store),
    getDaybookByCategory: store.getDaybookByCategory.bind(store)
  };
};
