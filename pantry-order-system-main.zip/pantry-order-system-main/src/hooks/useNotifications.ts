import { useState, useEffect } from 'react';

export interface Notification {
  id: string;
  type: 'order' | 'restock' | 'bill' | 'product';
  title: string;
  message: string;
  timestamp: string;
  isRead: boolean;
}

class NotificationStore {
  private static instance: NotificationStore;
  private subscribers: Set<() => void> = new Set();
  private notifications: Notification[] = [
    {
      id: '1',
      type: 'restock',
      title: 'Low Stock Alert',
      message: 'Wheat Flour is running low',
      timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
      isRead: false
    },
    {
      id: '2',
      type: 'order',
      title: 'New Order',
      message: 'Order ORD-004 received',
      timestamp: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
      isRead: false
    },
    {
      id: '3',
      type: 'bill',
      title: 'Bill Due',
      message: 'Internet payment due soon',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
      isRead: false
    }
  ];

  static getInstance() {
    if (!NotificationStore.instance) {
      NotificationStore.instance = new NotificationStore();
    }
    return NotificationStore.instance;
  }

  subscribe(callback: () => void) {
    this.subscribers.add(callback);
    return () => this.subscribers.delete(callback);
  }

  private notify() {
    this.subscribers.forEach(callback => callback());
  }

  getNotifications() {
    return [...this.notifications].sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }

  getUnreadCount() {
    return this.notifications.filter(n => !n.isRead).length;
  }

  addNotification(notification: Omit<Notification, 'id' | 'timestamp' | 'isRead'>) {
    const newNotification: Notification = {
      ...notification,
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      isRead: false
    };
    
    this.notifications.unshift(newNotification);
    
    // Keep only last 50 notifications
    if (this.notifications.length > 50) {
      this.notifications = this.notifications.slice(0, 50);
    }
    
    this.notify();
    console.log('New notification added:', newNotification);
  }

  markAsRead(notificationId: string) {
    const notification = this.notifications.find(n => n.id === notificationId);
    if (notification) {
      notification.isRead = true;
      this.notify();
    }
  }

  markAllAsRead() {
    this.notifications.forEach(n => n.isRead = true);
    this.notify();
  }

  clearAll() {
    this.notifications = [];
    this.notify();
  }
}

export const useNotifications = () => {
  const [, forceUpdate] = useState({});
  const store = NotificationStore.getInstance();

  useEffect(() => {
    const unsubscribe = store.subscribe(() => {
      forceUpdate({});
    });
    return () => {
      unsubscribe();
    };
  }, [store]);

  return {
    notifications: store.getNotifications(),
    unreadCount: store.getUnreadCount(),
    addNotification: store.addNotification.bind(store),
    markAsRead: store.markAsRead.bind(store),
    markAllAsRead: store.markAllAsRead.bind(store),
    clearAll: store.clearAll.bind(store)
  };
};
