
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Truck, 
  Package, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  Phone,
  MapPin,
  Clock,
  Search,
  DollarSign,
  User,
  Calendar
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface DeliveryViewProps {
  user: any;
  orders: any[];
  deliveries: any[];
  onUpdateDeliveryStatus: (orderId: number, status: string, deliveryPerson: string, notes?: string, returnReason?: string, damageDescription?: string, userId?: string, userName?: string) => void;
}

export const DeliveryView = ({ user, orders, deliveries, onUpdateDeliveryStatus }: DeliveryViewProps) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [deliveryAction, setDeliveryAction] = useState('');
  const [notes, setNotes] = useState('');
  const [returnReason, setReturnReason] = useState('');
  const [damageDescription, setDamageDescription] = useState('');
  const [activeTab, setActiveTab] = useState('orders');

  // Filter orders that are ready for delivery or in transit
  const deliveryOrders = orders.filter(order => 
    ['Processing', 'Ready for Delivery', 'In Transit'].includes(order.status)
  );

  const filteredOrders = deliveryOrders.filter(order =>
    order.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
    order.id.toString().includes(searchTerm) ||
    order.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Filter deliveries by status
  const myDeliveries = deliveries.filter(d => 
    d.deliveryPerson === user.name || d.deliveryPerson === undefined
  );

  const pendingDeliveries = myDeliveries.filter(d => d.status === 'pending');
  const inTransitDeliveries = myDeliveries.filter(d => d.status === 'in_transit');
  const completedDeliveries = myDeliveries.filter(d => ['delivered', 'returned', 'damaged'].includes(d.status));

  const getDeliveryStatus = (orderId: number) => {
    const delivery = deliveries.find(d => d.orderId === orderId);
    return delivery?.status || 'pending';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'in_transit': return 'bg-blue-100 text-blue-800';
      case 'delivered': return 'bg-green-100 text-green-800';
      case 'returned': return 'bg-red-100 text-red-800';
      case 'damaged': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPaymentTypeColor = (type: string) => {
    switch (type) {
      case 'cash': return 'bg-green-100 text-green-800';
      case 'credit': return 'bg-orange-100 text-orange-800';
      case 'debit': return 'bg-blue-100 text-blue-800';
      case 'transfer': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPaymentLabel = (type: string) => {
    switch (type) {
      case 'cash': return 'Cash on Delivery';
      case 'credit': return 'Credit (Loan)';
      case 'debit': return 'Pre-paid';
      case 'transfer': return 'Bank Transfer';
      default: return type;
    }
  };

  const handleDeliveryAction = (order: any, action: string) => {
    setSelectedOrder(order);
    setDeliveryAction(action);
    setNotes('');
    setReturnReason('');
    setDamageDescription('');
  };

  const handleSubmitDelivery = () => {
    if (!selectedOrder || !deliveryAction) return;

    let status = '';
    switch (deliveryAction) {
      case 'pickup':
        status = 'in_transit';
        break;
      case 'deliver':
        status = 'delivered';
        break;
      case 'return':
        status = 'returned';
        break;
      case 'damage':
        status = 'damaged';
        break;
    }

    // Pass user information to ensure daybook logging
    onUpdateDeliveryStatus(
      selectedOrder.id,
      status,
      user.name,
      notes,
      returnReason,
      damageDescription,
      user.id,
      user.name
    );

    alert(`Order #${selectedOrder.id} has been marked as ${status.replace('_', ' ')}`);
    setSelectedOrder(null);
    setDeliveryAction('');
  };

  // Check if user has delivery permissions
  const canDeliverOrders = ['Driver', 'Delivery Worker', 'Admin', 'Manager'].includes(user.role);

  if (!canDeliverOrders) {
    return (
      <div className="text-center py-12">
        <Truck className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">Access Denied</h3>
        <p className="text-gray-600">You don't have permission to access delivery management.</p>
      </div>
    );
  }

  const OrderCard = ({ order, showActions = true }: { order: any, showActions?: boolean }) => {
    const deliveryStatus = getDeliveryStatus(order.id);
    return (
      <Card className="hover:shadow-md transition-shadow">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="text-lg">Order #{order.id}</CardTitle>
              <CardDescription className="flex items-center mt-1">
                <User className="w-4 h-4 mr-1" />
                {order.customer}
              </CardDescription>
            </div>
            <div className="flex flex-col gap-2">
              <Badge className={getStatusColor(deliveryStatus)}>
                {deliveryStatus.replace('_', ' ').toUpperCase()}
              </Badge>
              <Badge className={getPaymentTypeColor(order.payment?.type || 'cash')}>
                {getPaymentLabel(order.payment?.type || 'cash')}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="flex items-center text-gray-600">
                <MapPin className="w-4 h-4 mr-2" />
                {order.location}
              </div>
              <div className="flex items-center text-gray-600">
                <Phone className="w-4 h-4 mr-2" />
                {order.phone}
              </div>
              <div className="flex items-center text-gray-600">
                <Calendar className="w-4 h-4 mr-2" />
                Due: {order.expectedDelivery}
              </div>
              <div className="flex items-center text-gray-600">
                <DollarSign className="w-4 h-4 mr-2" />
                ${order.total.toFixed(2)}
              </div>
            </div>

            <div className="pt-3 border-t">
              <p className="text-sm font-medium mb-2">Items ({order.items.length}):</p>
              <div className="space-y-1">
                {order.items.slice(0, 2).map((item: any, index: number) => (
                  <div key={index} className="text-xs text-gray-600 bg-gray-50 p-2 rounded">
                    {item.quantity}x {item.name} - ${(item.quantity * item.price).toFixed(2)}
                  </div>
                ))}
                {order.items.length > 2 && (
                  <div className="text-xs text-gray-500">
                    +{order.items.length - 2} more items
                  </div>
                )}
              </div>
            </div>

            {showActions && (
              <div className="flex gap-2 pt-2">
                {deliveryStatus === 'pending' && (
                  <Button 
                    size="sm" 
                    className="flex-1"
                    onClick={() => handleDeliveryAction(order, 'pickup')}
                  >
                    Pick Up Order
                  </Button>
                )}
                
                {deliveryStatus === 'in_transit' && (
                  <>
                    <Button 
                      size="sm" 
                      className="flex-1 bg-green-600 hover:bg-green-700"
                      onClick={() => handleDeliveryAction(order, 'deliver')}
                    >
                      <CheckCircle className="w-4 h-4 mr-1" />
                      Delivered
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      className="text-red-600 border-red-200 hover:bg-red-50"
                      onClick={() => handleDeliveryAction(order, 'return')}
                    >
                      <XCircle className="w-4 h-4 mr-1" />
                      Return
                    </Button>
                    <Button 
                      size="sm" 
                      variant="destructive"
                      onClick={() => handleDeliveryAction(order, 'damage')}
                    >
                      <AlertTriangle className="w-4 h-4 mr-1" />
                      Damaged
                    </Button>
                  </>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Delivery Dashboard</h2>
          <p className="text-gray-600">Manage your deliveries and order pickups</p>
        </div>
        <div className="flex items-center space-x-2 mt-4 sm:mt-0">
          <Badge variant="outline" className="bg-blue-50 text-blue-700">
            {user.name} - {user.role}
          </Badge>
        </div>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search orders by customer, ID, or location..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Delivery Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Clock className="w-8 h-8 text-yellow-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Pending Pickup</p>
                <p className="text-2xl font-bold text-gray-900">
                  {pendingDeliveries.length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Truck className="w-8 h-8 text-blue-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">In Transit</p>
                <p className="text-2xl font-bold text-gray-900">
                  {inTransitDeliveries.length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <CheckCircle className="w-8 h-8 text-green-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Delivered Today</p>
                <p className="text-2xl font-bold text-gray-900">
                  {completedDeliveries.filter(d => d.status === 'delivered' && d.deliveryDate === new Date().toISOString().split('T')[0]).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <AlertTriangle className="w-8 h-8 text-red-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Issues</p>
                <p className="text-2xl font-bold text-gray-900">
                  {completedDeliveries.filter(d => ['returned', 'damaged'].includes(d.status)).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs for different views */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="orders">Available Orders</TabsTrigger>
          <TabsTrigger value="active">My Active Deliveries</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>

        <TabsContent value="orders" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredOrders.map((order) => (
              <OrderCard key={order.id} order={order} />
            ))}
          </div>
          {filteredOrders.length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No orders available</h3>
                <p className="text-gray-600">All orders have been picked up or are not ready for delivery</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="active" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {orders.filter(order => {
              const delivery = deliveries.find(d => d.orderId === order.id);
              return delivery?.deliveryPerson === user.name && delivery?.status === 'in_transit';
            }).map((order) => (
              <OrderCard key={order.id} order={order} />
            ))}
          </div>
          {orders.filter(order => {
            const delivery = deliveries.find(d => d.orderId === order.id);
            return delivery?.deliveryPerson === user.name && delivery?.status === 'in_transit';
          }).length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <Truck className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No active deliveries</h3>
                <p className="text-gray-600">Pick up some orders to start making deliveries</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="completed" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {orders.filter(order => {
              const delivery = deliveries.find(d => d.orderId === order.id);
              return delivery?.deliveryPerson === user.name && ['delivered', 'returned', 'damaged'].includes(delivery?.status);
            }).map((order) => (
              <OrderCard key={order.id} order={order} showActions={false} />
            ))}
          </div>
          {orders.filter(order => {
            const delivery = deliveries.find(d => d.orderId === order.id);
            return delivery?.deliveryPerson === user.name && ['delivered', 'returned', 'damaged'].includes(delivery?.status);
          }).length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <CheckCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No completed deliveries</h3>
                <p className="text-gray-600">Your completed deliveries will appear here</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Delivery Action Dialog */}
      <Dialog open={!!selectedOrder} onOpenChange={() => setSelectedOrder(null)}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>
              {deliveryAction === 'pickup' && 'Pick Up Order'}
              {deliveryAction === 'deliver' && 'Confirm Delivery'}
              {deliveryAction === 'return' && 'Return Order'}
              {deliveryAction === 'damage' && 'Report Damage'}
            </DialogTitle>
            <DialogDescription>
              Order #{selectedOrder?.id} - {selectedOrder?.customer}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {deliveryAction === 'return' && (
              <div className="space-y-2">
                <Label htmlFor="returnReason">Return Reason *</Label>
                <Textarea
                  id="returnReason"
                  value={returnReason}
                  onChange={(e) => setReturnReason(e.target.value)}
                  placeholder="Please specify why the order is being returned (e.g., customer refused, address not found, customer not available, payment issues)..."
                  required
                  className="min-h-[80px]"
                />
              </div>
            )}
            
            {deliveryAction === 'damage' && (
              <div className="space-y-2">
                <Label htmlFor="damageDescription">Damage Description *</Label>
                <Textarea
                  id="damageDescription"
                  value={damageDescription}
                  onChange={(e) => setDamageDescription(e.target.value)}
                  placeholder="Please describe the damage to the goods..."
                  required
                  className="min-h-[80px]"
                />
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="notes">Additional Notes</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Any additional notes or comments..."
                className="min-h-[60px]"
              />
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setSelectedOrder(null)}>
              Cancel
            </Button>
            <Button 
              type="button" 
              onClick={handleSubmitDelivery}
              disabled={
                (deliveryAction === 'return' && !returnReason.trim()) ||
                (deliveryAction === 'damage' && !damageDescription.trim())
              }
            >
              Confirm
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
