
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { AddEmployeeForm } from './AddEmployeeForm';
import { 
  Users, 
  Search, 
  Plus, 
  Phone,
  Calendar,
  DollarSign,
  Briefcase,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { Employee } from '@/hooks/useDataStore';

interface EmployeesViewProps {
  user: any;
  employeesData: Employee[];
  onAddEmployee: (employeeData: any) => void;
  onUpdateEmployee: (employeeId: string, updates: Partial<Employee>) => void;
}

export const EmployeesView = ({ user, employeesData, onAddEmployee, onUpdateEmployee }: EmployeesViewProps) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('All');
  const [showAddEmployee, setShowAddEmployee] = useState(false);

  const handleAddEmployee = (employeeData: any) => {
    onAddEmployee(employeeData);
    alert(`Employee "${employeeData.name}" has been added successfully!`);
  };

  const handleToggleStatus = (employee: Employee) => {
    onUpdateEmployee(employee.id, { isActive: !employee.isActive });
    alert(`${employee.name} has been ${employee.isActive ? 'deactivated' : 'activated'}`);
  };

  const handleViewEmployeeDetails = (employee: Employee) => {
    const details = `
EMPLOYEE DETAILS
================
Employee ID: ${employee.id}
Name: ${employee.name}
Role: ${employee.role}
Salary: $${employee.salary.toFixed(2)}/month
Phone: ${employee.phone}
Email: ${employee.email || 'Not provided'}
Hire Date: ${employee.hireDate}
Status: ${employee.isActive ? 'Active' : 'Inactive'}

WORK DONE:
${employee.workDone.map(work => `- ${work}`).join('\n')}
    `;
    alert(details);
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'Admin': return 'bg-red-100 text-red-800';
      case 'Manager': return 'bg-purple-100 text-purple-800';
      case 'Salesperson': return 'bg-blue-100 text-blue-800';
      case 'Driver': return 'bg-green-100 text-green-800';
      case 'Clerk': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredEmployees = employeesData.filter(employee => {
    const matchesSearch = employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         employee.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         employee.phone.includes(searchTerm);
    const matchesRole = roleFilter === 'All' || employee.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  const roles = ['All', 'Admin', 'Manager', 'Salesperson', 'Driver', 'Clerk'];

  // Permission check - Only Admin and Manager can manage employees
  const canManageEmployees = user.role === 'Admin' || user.role === 'Manager';

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Employee Management</h2>
          <p className="text-gray-600">Manage your team and track their performance</p>
        </div>
        {canManageEmployees && (
          <Button 
            className="mt-4 sm:mt-0 bg-blue-600 hover:bg-blue-700"
            onClick={() => setShowAddEmployee(true)}
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Employee
          </Button>
        )}
      </div>

      {/* Search and Filter */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search employees..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2 flex-wrap">
              {roles.map(role => (
                <Button
                  key={role}
                  variant={roleFilter === role ? 'default' : 'outline'}
                  onClick={() => setRoleFilter(role)}
                  size="sm"
                >
                  {role}
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Employee Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Users className="w-8 h-8 text-blue-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Employees</p>
                <p className="text-2xl font-bold text-gray-900">{employeesData.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <CheckCircle className="w-8 h-8 text-green-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Active</p>
                <p className="text-2xl font-bold text-gray-900">
                  {employeesData.filter(e => e.isActive).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <DollarSign className="w-8 h-8 text-green-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Payroll</p>
                <p className="text-2xl font-bold text-gray-900">
                  ${employeesData.reduce((sum, emp) => sum + (emp.isActive ? emp.salary : 0), 0).toFixed(2)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Briefcase className="w-8 h-8 text-purple-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Avg Salary</p>
                <p className="text-2xl font-bold text-gray-900">
                  ${employeesData.length > 0 ? (employeesData.reduce((sum, emp) => sum + emp.salary, 0) / employeesData.length).toFixed(2) : '0.00'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Employees Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredEmployees.map((employee) => (
          <Card key={employee.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2">
                  <Users className="w-5 h-5 text-blue-600" />
                  <CardTitle className="text-lg">{employee.name}</CardTitle>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge className={getRoleColor(employee.role)}>
                    {employee.role}
                  </Badge>
                  {employee.isActive ? (
                    <CheckCircle className="w-4 h-4 text-green-600" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-600" />
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center text-sm text-gray-600">
                  <Phone className="w-4 h-4 mr-2" />
                  {employee.phone}
                </div>
                
                <div className="flex items-center text-sm text-gray-600">
                  <Calendar className="w-4 h-4 mr-2" />
                  Hired: {employee.hireDate}
                </div>

                <div className="flex items-center text-sm text-gray-600">
                  <DollarSign className="w-4 h-4 mr-2" />
                  Salary: ${employee.salary.toFixed(2)}/month
                </div>

                <div className="pt-3 border-t">
                  <p className="text-sm font-medium mb-2">Recent Work:</p>
                  <div className="space-y-1">
                    {employee.workDone.slice(-3).map((work, index) => (
                      <div key={index} className="text-xs text-gray-600 bg-gray-50 p-2 rounded">
                        {work}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1"
                    onClick={() => handleViewEmployeeDetails(employee)}
                  >
                    View Details
                  </Button>
                  
                  {canManageEmployees && (
                    <Button 
                      variant={employee.isActive ? "destructive" : "default"}
                      size="sm"
                      onClick={() => handleToggleStatus(employee)}
                    >
                      {employee.isActive ? 'Deactivate' : 'Activate'}
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredEmployees.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No employees found</h3>
            <p className="text-gray-600">Try adjusting your search or filter criteria</p>
          </CardContent>
        </Card>
      )}

      <AddEmployeeForm
        open={showAddEmployee}
        onClose={() => setShowAddEmployee(false)}
        onSubmit={handleAddEmployee}
      />
    </div>
  );
};
