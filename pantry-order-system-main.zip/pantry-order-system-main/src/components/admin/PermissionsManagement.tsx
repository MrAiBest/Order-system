
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { 
  Shield, 
  Plus, 
  Edit, 
  Trash2, 
  Key,
  UserCheck,
  Settings
} from 'lucide-react';

const initialPermissions = [
  { id: 'view_dashboard', label: 'View Dashboard', description: 'Access to main dashboard' },
  { id: 'view_inventory', label: 'View Inventory', description: 'View product inventory' },
  { id: 'add_inventory', label: 'Add Products', description: 'Add new products to inventory' },
  { id: 'edit_prices', label: 'Edit Product Prices', description: 'Modify product pricing' },
  { id: 'restock_products', label: 'Restock Products', description: 'Update product quantities' },
  { id: 'view_orders', label: 'View Orders', description: 'View customer orders' },
  { id: 'create_orders', label: 'Create Orders', description: 'Create new orders' },
  { id: 'update_order_status', label: 'Update Order Status', description: 'Change order status' },
  { id: 'print_invoices', label: 'Print Invoices', description: 'Generate and print invoices' },
  { id: 'view_bills', label: 'View Bills', description: 'View company bills' },
  { id: 'manage_bills', label: 'Manage Bills', description: 'Add and edit bills' },
  { id: 'pay_bills', label: 'Pay Bills', description: 'Process bill payments' },
  { id: 'view_analytics', label: 'View Analytics', description: 'Access analytics and reports' },
  { id: 'user_management', label: 'User Management', description: 'Manage system users' },
  { id: 'manage_deliveries', label: 'Manage Deliveries', description: 'Handle delivery operations' },
  { id: 'take_deliveries', label: 'Take Deliveries', description: 'Accept delivery assignments' },
  { id: 'full_access', label: 'Full System Access', description: 'Complete system access' }
];

const defaultRolePermissions = {
  Admin: ['full_access'],
  Manager: ['view_dashboard', 'view_inventory', 'view_orders', 'update_order_status', 'view_bills', 'manage_bills', 'pay_bills', 'view_analytics', 'manage_deliveries'],
  Clerk: ['view_dashboard', 'view_inventory', 'restock_products', 'view_orders', 'print_invoices', 'view_bills'],
  Salesperson: ['view_dashboard', 'view_inventory', 'view_orders', 'create_orders', 'print_invoices'],
  Driver: ['view_dashboard', 'view_orders', 'manage_deliveries', 'take_deliveries'],
  'Delivery Worker': ['view_dashboard', 'view_orders', 'manage_deliveries', 'take_deliveries']
};

export const PermissionsManagement = ({ user }) => {
  const [permissions, setPermissions] = useState(initialPermissions);
  const [rolePermissions, setRolePermissions] = useState(defaultRolePermissions);
  const [showAddPermission, setShowAddPermission] = useState(false);
  const [showEditPermission, setShowEditPermission] = useState(false);
  const [selectedPermission, setSelectedPermission] = useState(null);
  const [selectedRole, setSelectedRole] = useState('');
  const [showEditRolePermissions, setShowEditRolePermissions] = useState(false);
  const [newPermission, setNewPermission] = useState({
    id: '',
    label: '',
    description: ''
  });

  const handleAddPermission = (e) => {
    e.preventDefault();
    const permission = {
      ...newPermission,
      id: newPermission.id.toLowerCase().replace(/\s+/g, '_')
    };
    setPermissions(prev => [...prev, permission]);
    setNewPermission({ id: '', label: '', description: '' });
    setShowAddPermission(false);
    console.log('Added new permission:', permission);
    alert(`Permission "${permission.label}" has been added successfully!`);
  };

  const handleEditPermission = (e) => {
    e.preventDefault();
    setPermissions(prev => prev.map(p => p.id === selectedPermission.id ? selectedPermission : p));
    setShowEditPermission(false);
    setSelectedPermission(null);
    console.log('Updated permission:', selectedPermission);
    alert(`Permission "${selectedPermission.label}" has been updated!`);
  };

  const handleDeletePermission = (permissionId) => {
    if (confirm('Are you sure you want to delete this permission? This will remove it from all roles.')) {
      setPermissions(prev => prev.filter(p => p.id !== permissionId));
      // Remove from all roles
      setRolePermissions(prev => {
        const updated = { ...prev };
        Object.keys(updated).forEach(role => {
          updated[role] = updated[role].filter(p => p !== permissionId);
        });
        return updated;
      });
      console.log('Deleted permission:', permissionId);
      alert('Permission has been deleted successfully!');
    }
  };

  const handleRolePermissionChange = (permissionId, checked) => {
    setRolePermissions(prev => ({
      ...prev,
      [selectedRole]: checked 
        ? [...prev[selectedRole], permissionId]
        : prev[selectedRole].filter(p => p !== permissionId)
    }));
  };

  const handleUpdateRolePermissions = () => {
    console.log('Updated permissions for role:', selectedRole, rolePermissions[selectedRole]);
    setShowEditRolePermissions(false);
    setSelectedRole('');
    alert(`Permissions for ${selectedRole} role have been updated!`);
  };

  const getRoleColor = (role) => {
    switch (role) {
      case 'Admin': return 'bg-red-100 text-red-800';
      case 'Manager': return 'bg-purple-100 text-purple-800';
      case 'Clerk': return 'bg-yellow-100 text-yellow-800';
      case 'Salesperson': return 'bg-blue-100 text-blue-800';
      case 'Driver': return 'bg-green-100 text-green-800';
      case 'Delivery Worker': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (user.role !== 'Admin') {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Shield className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Access Denied</h3>
          <p className="text-gray-600">Only administrators can manage permissions.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Permissions Management</h2>
          <p className="text-gray-600">Manage system permissions and role assignments</p>
        </div>
        <Button 
          className="mt-4 sm:mt-0 bg-blue-600 hover:bg-blue-700"
          onClick={() => setShowAddPermission(true)}
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Permission
        </Button>
      </div>

      {/* Role Permissions Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Settings className="w-5 h-5 mr-2" />
            Role Permissions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Object.entries(rolePermissions).map(([role, perms]) => (
              <div key={role} className="space-y-2">
                <div className="flex items-center justify-between">
                  <Badge className={getRoleColor(role)}>{role}</Badge>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSelectedRole(role);
                      setShowEditRolePermissions(true);
                    }}
                  >
                    <Edit className="w-3 h-3" />
                  </Button>
                </div>
                <div className="text-sm text-gray-600">
                  <p className="font-medium">{perms.length} permissions assigned</p>
                  <ul className="space-y-1 mt-2">
                    {perms.slice(0, 3).map((permId) => {
                      const permission = permissions.find(p => p.id === permId);
                      return (
                        <li key={permId} className="flex items-center">
                          <UserCheck className="w-3 h-3 mr-2 text-green-500" />
                          {permission?.label || permId}
                        </li>
                      );
                    })}
                    {perms.length > 3 && (
                      <li className="text-xs text-gray-500">
                        +{perms.length - 3} more...
                      </li>
                    )}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* All Permissions List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Key className="w-5 h-5 mr-2" />
            All Permissions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {permissions.map((permission) => (
              <div key={permission.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <div className="font-medium">{permission.label}</div>
                  <div className="text-sm text-gray-600">{permission.description}</div>
                  <div className="text-xs text-gray-500 mt-1">ID: {permission.id}</div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSelectedPermission(permission);
                      setShowEditPermission(true);
                    }}
                  >
                    <Edit className="w-3 h-3" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeletePermission(permission.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Add Permission Dialog */}
      <Dialog open={showAddPermission} onOpenChange={setShowAddPermission}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Permission</DialogTitle>
            <DialogDescription>
              Create a new system permission that can be assigned to roles.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleAddPermission} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="permissionId">Permission ID *</Label>
              <Input
                id="permissionId"
                value={newPermission.id}
                onChange={(e) => setNewPermission(prev => ({ ...prev, id: e.target.value }))}
                placeholder="e.g., manage_reports"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="permissionLabel">Label *</Label>
              <Input
                id="permissionLabel"
                value={newPermission.label}
                onChange={(e) => setNewPermission(prev => ({ ...prev, label: e.target.value }))}
                placeholder="e.g., Manage Reports"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="permissionDescription">Description *</Label>
              <Input
                id="permissionDescription"
                value={newPermission.description}
                onChange={(e) => setNewPermission(prev => ({ ...prev, description: e.target.value }))}
                placeholder="e.g., Create and manage system reports"
                required
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShowAddPermission(false)}>
                Cancel
              </Button>
              <Button type="submit">Add Permission</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Permission Dialog */}
      <Dialog open={showEditPermission} onOpenChange={setShowEditPermission}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Permission</DialogTitle>
            <DialogDescription>
              Update the permission details.
            </DialogDescription>
          </DialogHeader>
          {selectedPermission && (
            <form onSubmit={handleEditPermission} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="editPermissionLabel">Label *</Label>
                <Input
                  id="editPermissionLabel"
                  value={selectedPermission.label}
                  onChange={(e) => setSelectedPermission(prev => ({ ...prev, label: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="editPermissionDescription">Description *</Label>
                <Input
                  id="editPermissionDescription"
                  value={selectedPermission.description}
                  onChange={(e) => setSelectedPermission(prev => ({ ...prev, description: e.target.value }))}
                  required
                />
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setShowEditPermission(false)}>
                  Cancel
                </Button>
                <Button type="submit">Update Permission</Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Role Permissions Dialog */}
      <Dialog open={showEditRolePermissions} onOpenChange={setShowEditRolePermissions}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Edit {selectedRole} Permissions</DialogTitle>
            <DialogDescription>
              Select the permissions for the {selectedRole} role.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-1 gap-4 py-4 max-h-96 overflow-y-auto">
            {permissions.map((permission) => (
              <div key={permission.id} className="flex items-start space-x-3 p-3 border rounded">
                <Checkbox
                  id={permission.id}
                  checked={rolePermissions[selectedRole]?.includes(permission.id)}
                  onCheckedChange={(checked) => handleRolePermissionChange(permission.id, checked === true)}
                />
                <div className="grid gap-1.5 leading-none">
                  <Label htmlFor={permission.id} className="text-sm font-medium">
                    {permission.label}
                  </Label>
                  <p className="text-xs text-gray-600">{permission.description}</p>
                </div>
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditRolePermissions(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdateRolePermissions}>
              Update Permissions
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
