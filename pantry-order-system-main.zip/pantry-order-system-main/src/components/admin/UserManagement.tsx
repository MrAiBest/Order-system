import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { 
  Users, 
  Plus, 
  Edit, 
  Trash2, 
  Shield, 
  Key,
  UserCheck,
  Settings
} from 'lucide-react';
import { PermissionsManagement } from './PermissionsManagement';

const initialUsers = [
  { id: 1, name: 'John Admin', email: 'admin@company.com', role: 'Admin', status: 'Active', lastLogin: '2024-06-03' },
  { id: 2, name: 'Sarah Manager', email: 'manager@company.com', role: 'Manager', status: 'Active', lastLogin: '2024-06-02' },
  { id: 3, name: 'Mike Clerk', email: 'clerk@company.com', role: 'Clerk', status: 'Active', lastLogin: '2024-06-03' },
  { id: 4, name: 'David Sales', email: 'sales@company.com', role: 'Salesperson', status: 'Active', lastLogin: '2024-06-03' },
  { id: 5, name: 'Mike Driver', email: 'driver@company.com', role: 'Driver', status: 'Active', lastLogin: '2024-06-03' },
  { id: 6, name: 'Sam Delivery', email: 'delivery@company.com', role: 'Delivery Worker', status: 'Active', lastLogin: '2024-06-03' }
];

const allPermissions = [
  { id: 'view_dashboard', label: 'View Dashboard' },
  { id: 'view_inventory', label: 'View Inventory' },
  { id: 'add_inventory', label: 'Add Products' },
  { id: 'edit_prices', label: 'Edit Product Prices' },
  { id: 'restock_products', label: 'Restock Products' },
  { id: 'view_orders', label: 'View Orders' },
  { id: 'create_orders', label: 'Create Orders' },
  { id: 'update_order_status', label: 'Update Order Status' },
  { id: 'print_invoices', label: 'Print Invoices' },
  { id: 'view_bills', label: 'View Bills' },
  { id: 'manage_bills', label: 'Manage Bills' },
  { id: 'pay_bills', label: 'Pay Bills' },
  { id: 'view_analytics', label: 'View Analytics' },
  { id: 'user_management', label: 'User Management' },
  { id: 'full_access', label: 'Full System Access' }
];

const defaultRolePermissions = {
  Admin: ['full_access'],
  Manager: ['view_dashboard', 'view_inventory', 'view_orders', 'update_order_status', 'view_bills', 'manage_bills', 'pay_bills', 'view_analytics'],
  Clerk: ['view_dashboard', 'view_inventory', 'restock_products', 'view_orders', 'print_invoices', 'view_bills'],
  Salesperson: ['view_dashboard', 'view_inventory', 'view_orders', 'create_orders', 'print_invoices'],
  Driver: ['view_dashboard', 'view_inventory', 'view_orders', 'create_orders', 'print_invoices'],
  'Delivery Worker': ['view_dashboard', 'view_inventory', 'view_orders', 'create_orders', 'print_invoices']
};

export const UserManagement = ({ user }) => {
  const [users, setUsers] = useState(initialUsers);
  const [rolePermissions, setRolePermissions] = useState(defaultRolePermissions);
  const [showAddUser, setShowAddUser] = useState(false);
  const [showEditUser, setShowEditUser] = useState(false);
  const [showResetPassword, setShowResetPassword] = useState(false);
  const [showEditPermissions, setShowEditPermissions] = useState(false);
  const [showPermissionsManagement, setShowPermissionsManagement] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [selectedRole, setSelectedRole] = useState('');
  const [newUser, setNewUser] = useState({
    name: '',
    email: '',
    role: 'Clerk',
    password: ''
  });

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    const userData = {
      id: users.length + 1,
      ...newUser,
      status: 'Active',
      lastLogin: 'Never'
    };
    console.log('Adding new user:', userData);
    setUsers(prev => [...prev, userData]);
    setNewUser({ name: '', email: '', role: 'Clerk', password: '' });
    setShowAddUser(false);
  };

  const handleEditUser = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Editing user:', selectedUser);
    setUsers(prev => prev.map(u => u.id === selectedUser.id ? selectedUser : u));
    setShowEditUser(false);
    setSelectedUser(null);
  };

  const handleResetPassword = () => {
    console.log('Resetting password for user:', selectedUser?.name);
    alert(`Password reset for ${selectedUser?.name}. New temporary password: temp123`);
    setShowResetPassword(false);
    setSelectedUser(null);
  };

  const handleDeleteUser = (userId: number) => {
    if (confirm('Are you sure you want to delete this user?')) {
      console.log('Deleting user:', userId);
      setUsers(prev => prev.filter(u => u.id !== userId));
    }
  };

  const handleUpdatePermissions = () => {
    console.log('Updated permissions for role:', selectedRole, rolePermissions[selectedRole]);
    setShowEditPermissions(false);
    setSelectedRole('');
  };

  const handlePermissionChange = (permissionId: string, checked: boolean) => {
    setRolePermissions(prev => ({
      ...prev,
      [selectedRole]: checked 
        ? [...prev[selectedRole], permissionId]
        : prev[selectedRole].filter(p => p !== permissionId)
    }));
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'Admin': return 'bg-red-100 text-red-800';
      case 'Manager': return 'bg-blue-100 text-blue-800';
      case 'Clerk': return 'bg-green-100 text-green-800';
      case 'Salesperson': return 'bg-orange-100 text-orange-800';
      case 'Driver': return 'bg-yellow-100 text-yellow-800';
      case 'Delivery Worker': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (user.role !== 'Admin') {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Shield className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Access Denied</h3>
          <p className="text-gray-600">Only administrators can access user management.</p>
        </div>
      </div>
    );
  }

  if (showPermissionsManagement) {
    return (
      <div className="space-y-4">
        <Button 
          variant="outline" 
          onClick={() => setShowPermissionsManagement(false)}
          className="mb-4"
        >
          ← Back to User Management
        </Button>
        <PermissionsManagement user={user} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">User Management</h2>
          <p className="text-gray-600">Manage users, roles, and permissions</p>
        </div>
        <div className="flex gap-2 mt-4 sm:mt-0">
          <Button 
            variant="outline"
            onClick={() => setShowPermissionsManagement(true)}
          >
            <Key className="w-4 h-4 mr-2" />
            Manage Permissions
          </Button>
          <Button 
            className="bg-blue-600 hover:bg-blue-700"
            onClick={() => setShowAddUser(true)}
          >
            <Plus className="w-4 h-4 mr-2" />
            Add User
          </Button>
        </div>
      </div>

      {/* Role Permissions Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Settings className="w-5 h-5 mr-2" />
            Role Permissions Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {Object.entries(rolePermissions).map(([role, permissions]) => (
              <div key={role} className="space-y-2">
                <div className="flex items-center justify-between">
                  <Badge className={getRoleColor(role)}>{role}</Badge>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSelectedRole(role);
                      setShowEditPermissions(true);
                    }}
                  >
                    <Edit className="w-3 h-3" />
                  </Button>
                </div>
                <ul className="space-y-1 text-sm text-gray-600">
                  {permissions.slice(0, 3).map((permissionId) => {
                    const permission = allPermissions.find(p => p.id === permissionId);
                    return (
                      <li key={permissionId} className="flex items-center">
                        <UserCheck className="w-3 h-3 mr-2 text-green-500" />
                        {permission?.label}
                      </li>
                    );
                  })}
                  {permissions.length > 3 && (
                    <li className="text-xs text-gray-500">
                      +{permissions.length - 3} more...
                    </li>
                  )}
                </ul>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Users List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Users className="w-5 h-5 mr-2" />
            System Users
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {users.map((userItem) => (
              <div key={userItem.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <Users className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <div className="font-medium">{userItem.name}</div>
                    <div className="text-sm text-gray-600">{userItem.email}</div>
                    <div className="text-xs text-gray-500">Last login: {userItem.lastLogin}</div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge className={getRoleColor(userItem.role)}>{userItem.role}</Badge>
                  <Badge variant="outline" className="text-green-600">{userItem.status}</Badge>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSelectedUser(userItem);
                      setShowEditUser(true);
                    }}
                  >
                    <Edit className="w-3 h-3" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSelectedUser(userItem);
                      setShowResetPassword(true);
                    }}
                  >
                    <Key className="w-3 h-3" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeleteUser(userItem.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Edit Permissions Dialog */}
      <Dialog open={showEditPermissions} onOpenChange={setShowEditPermissions}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Edit {selectedRole} Permissions</DialogTitle>
            <DialogDescription>
              Select the permissions for the {selectedRole} role.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-4">
            {allPermissions.map((permission) => (
              <div key={permission.id} className="flex items-center space-x-2">
                <Checkbox
                  id={permission.id}
                  checked={rolePermissions[selectedRole]?.includes(permission.id)}
                  onCheckedChange={(checked) => handlePermissionChange(permission.id, checked === true)}
                />
                <Label htmlFor={permission.id} className="text-sm">
                  {permission.label}
                </Label>
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditPermissions(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdatePermissions}>
              Update Permissions
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add User Dialog */}
      <Dialog open={showAddUser} onOpenChange={setShowAddUser}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New User</DialogTitle>
            <DialogDescription>
              Create a new user account with appropriate role and permissions.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleAddUser} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                value={newUser.name}
                onChange={(e) => setNewUser(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Enter full name"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={newUser.email}
                onChange={(e) => setNewUser(prev => ({ ...prev, email: e.target.value }))}
                placeholder="Enter email address"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="role">Role *</Label>
              <select
                id="role"
                value={newUser.role}
                onChange={(e) => setNewUser(prev => ({ ...prev, role: e.target.value }))}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                required
              >
                <option value="Clerk">Clerk</option>
                <option value="Salesperson">Salesperson</option>
                <option value="Manager">Manager</option>
                <option value="Admin">Admin</option>
                <option value="Driver">Driver</option>
                <option value="Delivery Worker">Delivery Worker</option>
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Initial Password *</Label>
              <Input
                id="password"
                type="password"
                value={newUser.password}
                onChange={(e) => setNewUser(prev => ({ ...prev, password: e.target.value }))}
                placeholder="Enter initial password"
                required
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShowAddUser(false)}>
                Cancel
              </Button>
              <Button type="submit">Add User</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit User Dialog */}
      <Dialog open={showEditUser} onOpenChange={setShowEditUser}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit User</DialogTitle>
            <DialogDescription>
              Update user information and role permissions.
            </DialogDescription>
          </DialogHeader>
          {selectedUser && (
            <form onSubmit={handleEditUser} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="editName">Full Name *</Label>
                <Input
                  id="editName"
                  value={selectedUser.name}
                  onChange={(e) => setSelectedUser(prev => ({ ...prev, name: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="editEmail">Email *</Label>
                <Input
                  id="editEmail"
                  type="email"
                  value={selectedUser.email}
                  onChange={(e) => setSelectedUser(prev => ({ ...prev, email: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="editRole">Role *</Label>
                <select
                  id="editRole"
                  value={selectedUser.role}
                  onChange={(e) => setSelectedUser(prev => ({ ...prev, role: e.target.value }))}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  required
                >
                  <option value="Clerk">Clerk</option>
                  <option value="Salesperson">Salesperson</option>
                  <option value="Manager">Manager</option>
                  <option value="Admin">Admin</option>
                  <option value="Driver">Driver</option>
                  <option value="Delivery Worker">Delivery Worker</option>
                </select>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setShowEditUser(false)}>
                  Cancel
                </Button>
                <Button type="submit">Update User</Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>

      {/* Reset Password Dialog */}
      <Dialog open={showResetPassword} onOpenChange={setShowResetPassword}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reset Password</DialogTitle>
            <DialogDescription>
              Are you sure you want to reset the password for {selectedUser?.name}?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowResetPassword(false)}>
              Cancel
            </Button>
            <Button onClick={handleResetPassword}>Reset Password</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
