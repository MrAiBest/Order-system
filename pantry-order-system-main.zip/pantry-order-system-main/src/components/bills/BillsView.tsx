
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { AddBillForm } from './AddBillForm';
import { 
  Receipt, 
  Search, 
  Plus, 
  Calendar,
  AlertCircle,
  CheckCircle,
  Clock,
  DollarSign,
  Eye,
  Edit,
  CreditCard
} from 'lucide-react';

export const BillsView = ({ user, billsData, onAddBill, onUpdateBillStatus }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [showAddBill, setShowAddBill] = useState(false);

  const handleAddBill = (billData) => {
    console.log('Bill added successfully:', billData);
    onAddBill(billData);
  };

  const handleMarkAsPaid = (billId) => {
    const today = new Date().toISOString().split('T')[0];
    onUpdateBillStatus(billId, 'Paid', today);
    console.log(`Bill ${billId} marked as paid`);
  };

  const handleViewDetails = (bill) => {
    const details = `
BILL DETAILS
============
Bill ID: ${bill.id}
Description: ${bill.description}
Category: ${bill.category}
Vendor: ${bill.vendor}
Amount: $${bill.amount.toFixed(2)}
Priority: ${bill.priority}
Issue Date: ${bill.issueDate}
Due Date: ${bill.dueDate}
Status: ${bill.status}
${bill.paidDate ? `Paid Date: ${bill.paidDate}` : ''}

NOTES:
- This bill ${bill.status === 'Paid' ? 'has been paid' : bill.status === 'Overdue' ? 'is overdue and requires immediate attention' : 'is pending payment'}
- Contact vendor: ${bill.vendor} for any questions
    `;
    alert(details);
  };

  const handleEditBill = (billId) => {
    console.log('Editing bill:', billId);
    alert(`Edit ${billId} - would open edit form`);
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Paid':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'Pending':
        return <Clock className="w-4 h-4 text-yellow-600" />;
      case 'Overdue':
        return <AlertCircle className="w-4 h-4 text-red-600" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Paid':
        return 'bg-green-100 text-green-800';
      case 'Pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'Overdue':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'High':
        return 'bg-red-100 text-red-800';
      case 'Medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'Low':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getDaysUntilDue = (dueDate) => {
    const today = new Date();
    const due = new Date(dueDate);
    const diffTime = due.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const filteredBills = billsData.filter(bill => {
    const matchesSearch = bill.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         bill.vendor.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         bill.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || bill.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const totalPending = billsData
    .filter(bill => bill.status === 'Pending' || bill.status === 'Overdue')
    .reduce((sum, bill) => sum + bill.amount, 0);

  const totalPaid = billsData
    .filter(bill => bill.status === 'Paid')
    .reduce((sum, bill) => sum + bill.amount, 0);

  // Updated Permissions - Only Admins can edit bills
  const canAddBills = user.role === 'Admin' || user.role === 'Manager';
  const canPayBills = user.role === 'Admin' || user.role === 'Manager' || user.permissions?.includes('Pay Bills');
  const canEditBills = user.role === 'Admin'; // Only Admins can edit

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Bill Management</h2>
          <p className="text-gray-600">Track and manage company expenses</p>
        </div>
        {canAddBills && (
          <Button 
            className="mt-4 sm:mt-0 bg-purple-600 hover:bg-purple-700"
            onClick={() => setShowAddBill(true)}
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Bill
          </Button>
        )}
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Pending</p>
                <p className="text-2xl font-bold text-red-600">${totalPending.toFixed(2)}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Paid</p>
                <p className="text-2xl font-bold text-green-600">${totalPaid.toFixed(2)}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">This Month</p>
                <p className="text-2xl font-bold text-blue-600">${(totalPending + totalPaid).toFixed(2)}</p>
              </div>
              <DollarSign className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filter */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search bills, vendors, or categories..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant={statusFilter === 'All' ? 'default' : 'outline'}
                onClick={() => setStatusFilter('All')}
                size="sm"
              >
                All
              </Button>
              <Button
                variant={statusFilter === 'Pending' ? 'default' : 'outline'}
                onClick={() => setStatusFilter('Pending')}
                size="sm"
              >
                Pending
              </Button>
              <Button
                variant={statusFilter === 'Overdue' ? 'default' : 'outline'}
                onClick={() => setStatusFilter('Overdue')}
                size="sm"
              >
                Overdue
              </Button>
              <Button
                variant={statusFilter === 'Paid' ? 'default' : 'outline'}
                onClick={() => setStatusFilter('Paid')}
                size="sm"
              >
                Paid
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Bills List */}
      <div className="space-y-4">
        {filteredBills.map((bill) => {
          const daysUntilDue = getDaysUntilDue(bill.dueDate);
          
          return (
            <Card key={bill.id} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <Receipt className="w-6 h-6 text-purple-600" />
                    <div>
                      <CardTitle className="text-lg">{bill.id}</CardTitle>
                      <CardDescription>{bill.description}</CardDescription>
                    </div>
                  </div>
                  <div className="flex flex-col items-end space-y-2">
                    <Badge className={getStatusColor(bill.status)}>
                      {getStatusIcon(bill.status)}
                      <span className="ml-1">{bill.status}</span>
                    </Badge>
                    <Badge className={getPriorityColor(bill.priority)}>
                      {bill.priority} Priority
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {/* Bill Details */}
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-gray-600">Category:</span>
                      <span className="text-sm font-medium">{bill.category}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-gray-600">Vendor:</span>
                      <span className="text-sm font-medium">{bill.vendor}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Calendar className="w-4 h-4 text-gray-500" />
                      <span className="text-sm text-gray-600">Issued: {bill.issueDate}</span>
                    </div>
                  </div>

                  {/* Due Date Info */}
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <Calendar className="w-4 h-4 text-gray-500" />
                      <span className="text-sm text-gray-600">Due: {bill.dueDate}</span>
                    </div>
                    {bill.status !== 'Paid' && (
                      <div className="text-sm">
                        {daysUntilDue > 0 ? (
                          <span className="text-yellow-600">{daysUntilDue} days remaining</span>
                        ) : daysUntilDue === 0 ? (
                          <span className="text-orange-600">Due today</span>
                        ) : (
                          <span className="text-red-600">{Math.abs(daysUntilDue)} days overdue</span>
                        )}
                      </div>
                    )}
                    {bill.paidDate && (
                      <div className="text-sm text-green-600">
                        Paid: {bill.paidDate}
                      </div>
                    )}
                  </div>

                  {/* Amount */}
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <DollarSign className="w-4 h-4 text-green-600" />
                      <span className="font-bold text-lg">${bill.amount.toFixed(2)}</span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="space-y-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full"
                      onClick={() => handleViewDetails(bill)}
                    >
                      <Eye className="w-3 h-3 mr-1" />
                      View Details
                    </Button>
                    {canPayBills && bill.status !== 'Paid' && (
                      <Button 
                        size="sm" 
                        className="w-full bg-green-600 hover:bg-green-700"
                        onClick={() => handleMarkAsPaid(bill.id)}
                      >
                        <CreditCard className="w-3 h-3 mr-1" />
                        Mark as Paid
                      </Button>
                    )}
                    {canEditBills && (
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full"
                        onClick={() => handleEditBill(bill.id)}
                      >
                        <Edit className="w-3 h-3 mr-1" />
                        Edit
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredBills.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <Receipt className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No bills found</h3>
            <p className="text-gray-600">Try adjusting your search or filter criteria</p>
          </CardContent>
        </Card>
      )}

      <AddBillForm
        open={showAddBill}
        onClose={() => setShowAddBill(false)}
        onSubmit={handleAddBill}
        user={user}
      />
    </div>
  );
};
