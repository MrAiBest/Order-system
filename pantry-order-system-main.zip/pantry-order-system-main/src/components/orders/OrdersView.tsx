
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { AddOrderForm } from './AddOrderForm';
import { 
  ShoppingCart, 
  Search, 
  Plus, 
  Eye,
  Printer,
  Clock,
  CheckCircle,
  AlertTriangle,
  Package
} from 'lucide-react';

export const OrdersView = ({ user, ordersData, inventoryData, onAddOrder, onUpdateOrderStatus }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [showAddOrder, setShowAddOrder] = useState(false);

  const handleAddOrder = (orderData) => {
    const newOrderData = {
      ...orderData,
      status: 'Processing',
      orderDate: new Date().toISOString().split('T')[0],
      salesperson: user.name
    };
    
    onAddOrder(newOrderData);
    alert(`Order for "${orderData.customer}" has been created and is now visible to all users! Inventory has been automatically updated.`);
  };

  const handleViewOrder = (order) => {
    const itemsList = order.items.map(item => 
      `  - ${item.name}: ${item.quantity}x @ $${item.price.toFixed(2)} = $${(item.quantity * item.price).toFixed(2)}`
    ).join('\n');
    
    const details = `
ORDER DETAILS
=============
Order ID: #${order.id}
Customer: ${order.customer}
Location: ${order.location}
Phone: ${order.phone}
Status: ${order.status}
Priority: ${order.priority}
Order Date: ${order.orderDate}
Expected Delivery: ${order.expectedDelivery}
Sales Representative: ${order.salesperson}

ITEMS ORDERED:
${itemsList}

TOTAL AMOUNT: $${order.total.toFixed(2)}

NOTES:
- Order is currently ${order.status.toLowerCase()}
- Customer contact: ${order.phone}
- Delivery location: ${order.location}
    `;
    alert(details);
  };

  const handlePrintInvoice = (orderId) => {
    console.log('Printing invoice for order:', orderId);
    alert(`Invoice for Order ${orderId} sent to printer`);
  };

  const handleUpdateStatus = (orderId, newStatus) => {
    onUpdateOrderStatus(orderId, newStatus);
    alert(`Order ${orderId} status updated to: ${newStatus}. All users can see this update instantly.`);
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Processing':
        return <Clock className="w-4 h-4 text-blue-600" />;
      case 'Delivered':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'Cancelled':
        return <AlertTriangle className="w-4 h-4 text-red-600" />;
      default:
        return <Package className="w-4 h-4 text-gray-600" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Processing':
        return 'bg-blue-100 text-blue-800';
      case 'Delivered':
        return 'bg-green-100 text-green-800';
      case 'Cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'High':
        return 'bg-red-100 text-red-800';
      case 'Medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'Low':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredOrders = ordersData.filter(order => {
    const matchesSearch = order.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         order.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || order.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Updated Permissions - Only specific roles can create orders, only Admin can update status
  const canCreateOrders = user.role === 'Admin' || user.role === 'Salesperson';
  const canUpdateStatus = user.role === 'Admin'; // Only Admin can update status
  const canPrintInvoices = user.role === 'Admin' || user.role === 'Clerk' || user.role === 'Salesperson';

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Order Management</h2>
          <p className="text-gray-600">Track and manage customer orders - all updates are shared instantly</p>
        </div>
        {canCreateOrders && (
          <Button 
            className="mt-4 sm:mt-0 bg-green-600 hover:bg-green-700"
            onClick={() => setShowAddOrder(true)}
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Order
          </Button>
        )}
      </div>

      {/* Search and Filter */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search orders..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant={statusFilter === 'All' ? 'default' : 'outline'}
                onClick={() => setStatusFilter('All')}
                size="sm"
              >
                All
              </Button>
              <Button
                variant={statusFilter === 'Processing' ? 'default' : 'outline'}
                onClick={() => setStatusFilter('Processing')}
                size="sm"
              >
                Processing
              </Button>
              <Button
                variant={statusFilter === 'Delivered' ? 'default' : 'outline'}
                onClick={() => setStatusFilter('Delivered')}
                size="sm"
              >
                Delivered
              </Button>
              <Button
                variant={statusFilter === 'Cancelled' ? 'default' : 'outline'}
                onClick={() => setStatusFilter('Cancelled')}
                size="sm"
              >
                Cancelled
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Orders Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredOrders.map((order) => (
          <Card key={order.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2">
                  <ShoppingCart className="w-5 h-5 text-green-600" />
                  <CardTitle className="text-lg">Order #{order.id}</CardTitle>
                </div>
                <Badge className={getStatusColor(order.status)}>
                  {getStatusIcon(order.status)}
                  <span className="ml-1">{order.status}</span>
                </Badge>
              </div>
              <CardDescription>
                <div className="space-y-1">
                  <div><strong>Customer:</strong> {order.customer}</div>
                  <div><strong>Location:</strong> {order.location}</div>
                  <div><strong>Phone:</strong> {order.phone}</div>
                </div>
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm">Order Items:</h4>
                  {order.items.map((item, index) => (
                    <div key={index} className="flex justify-between items-center text-sm">
                      <span>{item.name}</span>
                      <span>{item.quantity}x @ ${item.price}</span>
                    </div>
                  ))}
                </div>

                <div className="flex justify-between items-center pt-2 border-t">
                  <span className="font-medium">Total:</span>
                  <span className="font-bold text-lg">${order.total.toFixed(2)}</span>
                </div>

                <div className="flex justify-between items-center text-sm text-gray-600">
                  <span>Priority: <Badge className={getPriorityColor(order.priority)}>{order.priority}</Badge></span>
                  <span>Expected: {order.expectedDelivery}</span>
                </div>

                <div className="text-xs text-gray-500">
                  Order Date: {order.orderDate} | Sales: {order.salesperson}
                </div>

                <div className="flex gap-2 pt-2">
                  <Button variant="outline" size="sm" onClick={() => handleViewOrder(order)}>
                    <Eye className="w-3 h-3 mr-1" />
                    View
                  </Button>
                  
                  {canPrintInvoices && (
                    <Button variant="outline" size="sm" onClick={() => handlePrintInvoice(order.id)}>
                      <Printer className="w-3 h-3 mr-1" />
                      Print
                    </Button>
                  )}

                  {canUpdateStatus && order.status === 'Processing' && (
                    <Button 
                      size="sm" 
                      className="bg-green-600 hover:bg-green-700"
                      onClick={() => handleUpdateStatus(order.id, 'Delivered')}
                    >
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Deliver
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredOrders.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <ShoppingCart className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No orders found</h3>
            <p className="text-gray-600">Try adjusting your search or filter criteria</p>
          </CardContent>
        </Card>
      )}

      <AddOrderForm
        open={showAddOrder}
        onClose={() => setShowAddOrder(false)}
        onSubmit={handleAddOrder}
        user={user}
        inventoryData={inventoryData}
      />
    </div>
  );
};
