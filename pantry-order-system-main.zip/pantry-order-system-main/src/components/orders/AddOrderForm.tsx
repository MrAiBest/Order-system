
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Plus, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface AddOrderFormProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (orderData: any) => void;
  user: any;
  inventoryData: any[];
}

export const AddOrderForm = ({ open, onClose, onSubmit, user, inventoryData }: AddOrderFormProps) => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    customer: '',
    location: '',
    phone: '',
    email: '',
    items: [{ name: '', quantity: 1, price: 0 }],
    priority: 'Medium',
    expectedDelivery: '',
    payment: {
      type: 'cash',
      reference: ''
    }
  });

  const validateStock = (items: typeof formData.items) => {
    const errors: string[] = [];
    
    items.forEach((item, index) => {
      if (item.name) {
        const product = inventoryData.find(p => p.name === item.name);
        if (product) {
          if (product.current === 0) {
            errors.push(`${product.name} is currently out of stock`);
          } else if (item.quantity > product.current) {
            errors.push(`${product.name}: Only ${product.current} units available, but ${item.quantity} requested`);
          }
        }
      }
    });
    
    return errors;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate stock before submitting
    const stockErrors = validateStock(formData.items);
    
    if (stockErrors.length > 0) {
      stockErrors.forEach(error => {
        toast({
          variant: "destructive",
          title: "Stock Issue",
          description: error,
        });
      });
      return;
    }
    
    const total = formData.items.reduce((sum, item) => sum + (item.quantity * item.price), 0);
    const orderData = {
      ...formData,
      total,
      payment: {
        ...formData.payment,
        amount: total,
        timestamp: new Date().toISOString()
      }
    };
    console.log('Adding new order:', orderData);
    onSubmit(orderData);
    
    // Reset form
    setFormData({
      customer: '',
      location: '',
      phone: '',
      email: '',
      items: [{ name: '', quantity: 1, price: 0 }],
      priority: 'Medium',
      expectedDelivery: '',
      payment: {
        type: 'cash',
        reference: ''
      }
    });
    onClose();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handlePaymentChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      payment: {
        ...prev.payment,
        [name]: value
      }
    }));
  };

  const handleItemChange = (index: number, field: string, value: string | number) => {
    const updatedItems = [...formData.items];
    
    if (field === 'name') {
      // Auto-fill price when product is selected
      const selectedProduct = inventoryData.find(p => p.name === value);
      updatedItems[index] = {
        ...updatedItems[index],
        name: value as string,
        price: selectedProduct ? selectedProduct.price : 0
      };
      
      // Check stock immediately when product is selected
      if (selectedProduct && selectedProduct.current === 0) {
        toast({
          variant: "destructive",
          title: "Out of Stock",
          description: `${selectedProduct.name} is currently out of stock`,
        });
      }
    } else if (field === 'quantity') {
      const newQuantity = typeof value === 'string' ? parseFloat(value) || 0 : value;
      updatedItems[index] = {
        ...updatedItems[index],
        quantity: newQuantity
      };
      
      // Check stock when quantity changes
      const product = inventoryData.find(p => p.name === updatedItems[index].name);
      if (product && newQuantity > product.current) {
        toast({
          variant: "destructive",
          title: "Insufficient Stock",
          description: `Only ${product.current} units of ${product.name} available. Please order up to ${product.current} units.`,
        });
      }
    } else if (field === 'price') {
      updatedItems[index] = {
        ...updatedItems[index],
        price: typeof value === 'string' ? parseFloat(value) || 0 : value
      };
    }
    
    setFormData(prev => ({
      ...prev,
      items: updatedItems
    }));
  };

  const addItem = () => {
    setFormData(prev => ({
      ...prev,
      items: [...prev.items, { name: '', quantity: 1, price: 0 }]
    }));
  };

  const removeItem = (index: number) => {
    if (formData.items.length > 1) {
      setFormData(prev => ({
        ...prev,
        items: prev.items.filter((_, i) => i !== index)
      }));
    }
  };

  const calculateTotal = () => {
    return formData.items.reduce((sum, item) => sum + (item.quantity * item.price), 0);
  };

  // Only admin can manually set prices
  const canSetPrice = user?.role === 'Admin';

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create New Order</DialogTitle>
          <DialogDescription>
            Enter the order details and items for the customer. Orders are automatically shared with all users.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Customer Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Customer Information</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="customer">Customer Name *</Label>
                <Input
                  id="customer"
                  name="customer"
                  value={formData.customer}
                  onChange={handleChange}
                  placeholder="e.g. Sunshine Supermarket"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number *</Label>
                <Input
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="e.g. +1-555-0123"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="location">Location *</Label>
                <Input
                  id="location"
                  name="location"
                  value={formData.location}
                  onChange={handleChange}
                  placeholder="e.g. Downtown District"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="email">Email (Optional)</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="e.g. contact@client.com"
                />
              </div>
            </div>
          </div>

          {/* Order Details */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Order Details</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="priority">Priority</Label>
                <select
                  id="priority"
                  name="priority"
                  value={formData.priority}
                  onChange={handleChange}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
                >
                  <option value="Low">Low</option>
                  <option value="Medium">Medium</option>
                  <option value="High">High</option>
                </select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="expectedDelivery">Expected Delivery *</Label>
                <Input
                  id="expectedDelivery"
                  name="expectedDelivery"
                  type="date"
                  value={formData.expectedDelivery}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>
          </div>

          {/* Payment Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Payment Information</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="payment-type">Payment Method *</Label>
                <select
                  id="payment-type"
                  name="type"
                  value={formData.payment.type}
                  onChange={handlePaymentChange}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
                  required
                >
                  <option value="cash">Cash on Delivery</option>
                  <option value="transfer">Bank Transfer</option>
                  <option value="credit">Credit (Customer pays later - Loan)</option>
                  <option value="debit">Debit (Customer pays first - Pre-payment)</option>
                </select>
              </div>
              
              {formData.payment.type !== 'cash' && (
                <div className="space-y-2">
                  <Label htmlFor="payment-reference">Reference/Transaction ID</Label>
                  <Input
                    id="payment-reference"
                    name="reference"
                    value={formData.payment.reference}
                    onChange={handlePaymentChange}
                    placeholder="e.g. TXN123456 or Card ending 1234"
                  />
                </div>
              )}
            </div>
            
            {/* Payment explanations */}
            <div className="text-sm text-gray-600 bg-blue-50 p-3 rounded">
              <div className="font-medium mb-2">Payment Types:</div>
              <div className="space-y-1">
                <div><strong>Cash:</strong> Payment on delivery</div>
                <div><strong>Credit (Loan):</strong> Customer receives goods now and pays later</div>
                <div><strong>Debit (Pre-payment):</strong> Customer pays first then receives goods later</div>
                <div><strong>Transfer:</strong> Bank transfer payment</div>
              </div>
            </div>
          </div>

          {/* Items */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Order Items</h3>
              <Button type="button" variant="outline" size="sm" onClick={addItem}>
                <Plus className="w-4 h-4 mr-2" />
                Add Item
              </Button>
            </div>

            {formData.items.map((item, index) => {
              const product = inventoryData.find(p => p.name === item.name);
              const isOutOfStock = product && product.current === 0;
              const exceedsStock = product && item.quantity > product.current;
              
              return (
                <div key={index} className="grid grid-cols-12 gap-2 items-end">
                  <div className="col-span-5 space-y-2">
                    <Label>Product Name</Label>
                    <select
                      value={item.name}
                      onChange={(e) => handleItemChange(index, 'name', e.target.value)}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
                      required
                    >
                      <option value="">Select Product</option>
                      {inventoryData.map((product) => (
                        <option key={product.id} value={product.name}>
                          {product.name} (Stock: {product.current})
                          {product.current === 0 && ' - OUT OF STOCK'}
                        </option>
                      ))}
                    </select>
                    {isOutOfStock && (
                      <p className="text-sm text-red-600">⚠️ Out of stock</p>
                    )}
                  </div>
                  <div className="col-span-2 space-y-2">
                    <Label>Quantity</Label>
                    <Input
                      type="number"
                      value={item.quantity}
                      onChange={(e) => handleItemChange(index, 'quantity', e.target.value)}
                      min="1"
                      max={product?.current || undefined}
                      required
                      className={exceedsStock ? 'border-red-500' : ''}
                    />
                    {exceedsStock && (
                      <p className="text-sm text-red-600">Max: {product?.current}</p>
                    )}
                  </div>
                  <div className="col-span-3 space-y-2">
                    <Label>Unit Price</Label>
                    {canSetPrice ? (
                      <Input
                        type="number"
                        step="0.01"
                        value={item.price}
                        onChange={(e) => handleItemChange(index, 'price', e.target.value)}
                        min="0"
                        required
                      />
                    ) : (
                      <div className="flex h-10 items-center px-3 border rounded-md bg-gray-50 text-sm">
                        ${item.price.toFixed(2)}
                      </div>
                    )}
                  </div>
                  <div className="col-span-1 space-y-2">
                    <Label>Total</Label>
                    <div className="flex h-10 items-center text-sm font-medium">
                      ${(item.quantity * item.price).toFixed(2)}
                    </div>
                  </div>
                  <div className="col-span-1">
                    {formData.items.length > 1 && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => removeItem(index)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}

            {!canSetPrice && (
              <div className="text-sm text-gray-600 bg-blue-50 p-2 rounded">
                Note: Prices are automatically set from inventory. Only administrators can modify prices.
              </div>
            )}

            <div className="flex justify-end pt-4 border-t">
              <div className="text-lg font-semibold">
                Total: ${calculateTotal().toFixed(2)}
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" className="bg-green-600 hover:bg-green-700">
              Create Order
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
