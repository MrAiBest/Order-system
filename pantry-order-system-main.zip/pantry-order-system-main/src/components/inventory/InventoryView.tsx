
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { AddProductForm } from './AddProductForm';
import { RestockForm } from './RestockForm';
import { 
  Package, 
  Search, 
  Plus, 
  AlertTriangle,
  CheckCircle,
  XCircle,
  Edit,
  PackagePlus,
  Printer,
  Eye
} from 'lucide-react';

export const InventoryView = ({ user, inventoryData, onAddProduct, onRestockProduct }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [showRestockForm, setShowRestockForm] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);

  const handleAddProduct = (productData) => {
    const newProduct = {
      name: productData.name,
      category: productData.category,
      current: productData.currentStock,
      minimum: productData.minimumLevel,
      price: productData.unitPrice || 0,
      supplier: productData.supplier
    };
    
    onAddProduct(newProduct);
    alert(`Product "${productData.name}" has been added to inventory and is now visible to all users!`);
  };

  const handleViewDetails = (item) => {
    const stockPercentage = ((item.current / (item.minimum * 2)) * 100).toFixed(1);
    const details = `
PRODUCT DETAILS
===============
Product ID: ${item.id}
Name: ${item.name}
Category: ${item.category}
Current Stock: ${item.current} units
Minimum Level: ${item.minimum} units
Unit Price: $${item.price.toFixed(2)}
Status: ${item.status}
Supplier: ${item.supplier}

STOCK ANALYSIS:
- Stock Level: ${stockPercentage}% of optimal
- Value in Stock: $${(item.current * item.price).toFixed(2)}
- Reorder Point: ${item.minimum} units

RECOMMENDATIONS:
${item.current === 0 ? '⚠️ URGENT: Product is out of stock!' : 
  item.current < item.minimum ? '🔄 Restock recommended soon' : 
  '✅ Stock levels are adequate'}

SUPPLIER INFO:
Contact ${item.supplier} for restocking
    `;
    alert(details);
  };

  const handleEditProduct = (productId) => {
    console.log('Editing product:', productId);
    alert(`Edit Product ${productId} - would open edit form`);
  };

  const handleRestock = (quantity) => {
    if (selectedProduct) {
      onRestockProduct(selectedProduct.id, quantity);
      alert(`Product "${selectedProduct.name}" restocked with ${quantity} units! All users can see this update instantly.`);
    }
  };

  const handlePrintReport = () => {
    console.log('Printing inventory report');
    alert('Inventory report sent to printer');
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'In Stock':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'Low Stock':
        return <AlertTriangle className="w-4 h-4 text-orange-600" />;
      case 'Out of Stock':
        return <XCircle className="w-4 h-4 text-red-600" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'In Stock':
        return 'bg-green-100 text-green-800';
      case 'Low Stock':
        return 'bg-orange-100 text-orange-800';
      case 'Out of Stock':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredInventory = inventoryData.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'All' || item.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  // Permissions: Admin can do everything, Clerk can restock, Salesperson has limited access
  const canAddProduct = user.role === 'Admin';
  const canEditPrices = user.role === 'Admin'; // Only Admin can edit
  const canRestock = user.role === 'Admin' || user.role === 'Clerk';
  const canPrintReports = user.role === 'Admin' || user.role === 'Clerk' || user.role === 'Salesperson';

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Inventory Management</h2>
          <p className="text-gray-600">Track and manage your product inventory</p>
        </div>
        <div className="flex gap-2 mt-4 sm:mt-0">
          {canAddProduct && (
            <Button 
              className="bg-blue-600 hover:bg-blue-700"
              onClick={() => setShowAddProduct(true)}
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Product
            </Button>
          )}
          {canRestock && !canAddProduct && (
            <Button 
              className="bg-green-600 hover:bg-green-700"
              onClick={() => alert('Please select a product to restock by clicking the Restock button on any product card.')}
            >
              <PackagePlus className="w-4 h-4 mr-2" />
              Restock Products
            </Button>
          )}
          {canPrintReports && (
            <Button 
              variant="outline"
              onClick={handlePrintReport}
            >
              <Printer className="w-4 h-4 mr-2" />
              Print Report
            </Button>
          )}
        </div>
      </div>

      {/* Search and Filter */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant={categoryFilter === 'All' ? 'default' : 'outline'}
                onClick={() => setCategoryFilter('All')}
                size="sm"
              >
                All
              </Button>
              <Button
                variant={categoryFilter === 'Foodstuffs' ? 'default' : 'outline'}
                onClick={() => setCategoryFilter('Foodstuffs')}
                size="sm"
              >
                Foodstuffs
              </Button>
              <Button
                variant={categoryFilter === 'Household' ? 'default' : 'outline'}
                onClick={() => setCategoryFilter('Household')}
                size="sm"
              >
                Household
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Inventory Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredInventory.map((item) => (
          <Card key={item.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2">
                  <Package className="w-5 h-5 text-blue-600" />
                  <CardTitle className="text-lg">{item.name}</CardTitle>
                </div>
                <Badge className={getStatusColor(item.status)}>
                  {getStatusIcon(item.status)}
                  <span className="ml-1">{item.status}</span>
                </Badge>
              </div>
              <CardDescription>{item.category}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Quantity in Stock:</span>
                  <span className="font-bold text-xl text-blue-600">
                    {item.current} {item.current === 1 ? 'unit' : 'units'}
                  </span>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Minimum Level:</span>
                  <span className="text-sm">{item.minimum}</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Unit Price:</span>
                  <span className="font-medium">${item.price}</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Supplier:</span>
                  <span className="text-sm">{item.supplier}</span>
                </div>

                {/* Stock Level Bar */}
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${
                      item.current === 0 ? 'bg-red-500' :
                      item.current < item.minimum ? 'bg-orange-500' : 'bg-green-500'
                    }`}
                    style={{ 
                      width: `${Math.min((item.current / (item.minimum * 2)) * 100, 100)}%` 
                    }}
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1"
                    onClick={() => handleViewDetails(item)}
                  >
                    <Eye className="w-3 h-3 mr-1" />
                    View Details
                  </Button>
                  {canEditPrices && (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1"
                      onClick={() => handleEditProduct(item.id)}
                    >
                      <Edit className="w-3 h-3 mr-1" />
                      Edit
                    </Button>
                  )}
                  {canRestock && (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1"
                      onClick={() => {
                        setSelectedProduct(item);
                        setShowRestockForm(true);
                      }}
                    >
                      <PackagePlus className="w-3 h-3 mr-1" />
                      Restock
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredInventory.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No products found</h3>
            <p className="text-gray-600">Try adjusting your search or filter criteria</p>
          </CardContent>
        </Card>
      )}

      <AddProductForm
        open={showAddProduct}
        onClose={() => setShowAddProduct(false)}
        onSubmit={handleAddProduct}
        user={user}
      />

      <RestockForm
        open={showRestockForm}
        onClose={() => setShowRestockForm(false)}
        onSubmit={handleRestock}
        productName={selectedProduct?.name || ''}
        currentStock={selectedProduct?.current || 0}
      />
    </div>
  );
};
