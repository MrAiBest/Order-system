
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface AddProductFormProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (productData: any) => void;
  user?: any;
}

export const AddProductForm = ({ open, onClose, onSubmit, user }: AddProductFormProps) => {
  const [formData, setFormData] = useState({
    name: '',
    category: 'Foodstuffs',
    currentStock: 0,
    minimumLevel: 0,
    unitPrice: 0,
    supplier: '',
    description: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Adding new product:', formData);
    onSubmit(formData);
    
    // Reset form
    setFormData({
      name: '',
      category: 'Foodstuffs',
      currentStock: 0,
      minimumLevel: 0,
      unitPrice: 0,
      supplier: '',
      description: ''
    });
    onClose();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'currentStock' || name === 'minimumLevel' || name === 'unitPrice' 
        ? parseFloat(value) || 0 
        : value
    }));
  };

  // Only admin can set prices
  const canSetPrice = user?.role === 'Admin';

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Add New Product</DialogTitle>
          <DialogDescription>
            Enter the product details to add to inventory.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Product Name *</Label>
              <Input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="e.g. Sugar (50kg bags)"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="category">Category *</Label>
              <select
                id="category"
                name="category"
                value={formData.category}
                onChange={handleChange}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
                required
              >
                <option value="Foodstuffs">Foodstuffs</option>
                <option value="Household">Household</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="currentStock">Current Stock *</Label>
              <Input
                id="currentStock"
                name="currentStock"
                type="number"
                value={formData.currentStock}
                onChange={handleChange}
                min="0"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="minimumLevel">Minimum Level *</Label>
              <Input
                id="minimumLevel"
                name="minimumLevel"
                type="number"
                value={formData.minimumLevel}
                onChange={handleChange}
                min="0"
                required
              />
            </div>

            {canSetPrice && (
              <div className="space-y-2">
                <Label htmlFor="unitPrice">Unit Price *</Label>
                <Input
                  id="unitPrice"
                  name="unitPrice"
                  type="number"
                  step="0.01"
                  value={formData.unitPrice}
                  onChange={handleChange}
                  min="0"
                  required
                />
              </div>
            )}
          </div>

          {!canSetPrice && (
            <div className="text-sm text-gray-600 bg-yellow-50 p-2 rounded">
              Note: Product prices will be set by an administrator.
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="supplier">Supplier *</Label>
            <Input
              id="supplier"
              name="supplier"
              value={formData.supplier}
              onChange={handleChange}
              placeholder="e.g. Sweet Supplies Ltd"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              placeholder="Additional product details..."
              rows={3}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
              Add Product
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
