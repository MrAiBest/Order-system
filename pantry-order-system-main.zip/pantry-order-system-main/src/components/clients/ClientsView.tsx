
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { AddClientForm } from './AddClientForm';
import { 
  Users, 
  Search, 
  Plus, 
  Phone,
  MapPin,
  Calendar,
  DollarSign,
  ShoppingBag
} from 'lucide-react';
import { Client } from '@/hooks/useDataStore';

interface ClientsViewProps {
  user: any;
  clientsData: Client[];
  onAddClient: (clientData: any) => void;
}

export const ClientsView = ({ user, clientsData, onAddClient }: ClientsViewProps) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddClient, setShowAddClient] = useState(false);

  const handleAddClient = (clientData: any) => {
    onAddClient(clientData);
    alert(`Client "${clientData.name}" has been added successfully!`);
  };

  const handleViewClientDetails = (client: Client) => {
    const details = `
CLIENT DETAILS
==============
Client ID: ${client.id}
Name: ${client.name}
Location: ${client.location}
Phone: ${client.phone}
Email: ${client.email || 'Not provided'}
Total Purchases: $${client.totalPurchases.toFixed(2)}
Last Order: ${client.lastOrderDate || 'No orders yet'}
Client Since: ${client.createdDate}
Total Orders: ${client.orders.length}

PURCHASE HISTORY:
- Orders: ${client.orders.join(', ') || 'No orders yet'}
    `;
    alert(details);
  };

  const filteredClients = clientsData.filter(client => 
    client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.phone.includes(searchTerm)
  );

  // Permission check - Only Admin can manually add clients
  const canAddClients = user.role === 'Admin';

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Client Management</h2>
          <p className="text-gray-600">Manage your clients and view their purchase history</p>
        </div>
        {canAddClients && (
          <Button 
            className="mt-4 sm:mt-0 bg-blue-600 hover:bg-blue-700"
            onClick={() => setShowAddClient(true)}
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Client
          </Button>
        )}
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search clients by name, location, or phone..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Clients Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Users className="w-8 h-8 text-blue-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Clients</p>
                <p className="text-2xl font-bold text-gray-900">{clientsData.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <DollarSign className="w-8 h-8 text-green-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Revenue</p>
                <p className="text-2xl font-bold text-gray-900">
                  ${clientsData.reduce((sum, client) => sum + client.totalPurchases, 0).toFixed(2)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <ShoppingBag className="w-8 h-8 text-purple-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Orders</p>
                <p className="text-2xl font-bold text-gray-900">
                  {clientsData.reduce((sum, client) => sum + client.orders.length, 0)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Clients Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredClients.map((client) => (
          <Card key={client.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2">
                  <Users className="w-5 h-5 text-blue-600" />
                  <CardTitle className="text-lg">{client.name}</CardTitle>
                </div>
                <Badge variant="outline" className="text-xs">
                  {client.id}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center text-sm text-gray-600">
                  <MapPin className="w-4 h-4 mr-2" />
                  {client.location}
                </div>
                
                <div className="flex items-center text-sm text-gray-600">
                  <Phone className="w-4 h-4 mr-2" />
                  {client.phone}
                </div>

                <div className="flex items-center text-sm text-gray-600">
                  <Calendar className="w-4 h-4 mr-2" />
                  Client since: {client.createdDate}
                </div>

                <div className="pt-3 border-t space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Total Purchases:</span>
                    <span className="font-bold text-green-600">${client.totalPurchases.toFixed(2)}</span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Orders:</span>
                    <span className="font-medium">{client.orders.length}</span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Last Order:</span>
                    <span className="text-sm">{client.lastOrderDate || 'None'}</span>
                  </div>
                </div>

                <div className="pt-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full"
                    onClick={() => handleViewClientDetails(client)}
                  >
                    View Details
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredClients.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No clients found</h3>
            <p className="text-gray-600">
              {searchTerm ? 'Try adjusting your search criteria' : 'Clients will appear here when orders are created'}
            </p>
          </CardContent>
        </Card>
      )}

      <AddClientForm
        open={showAddClient}
        onClose={() => setShowAddClient(false)}
        onSubmit={handleAddClient}
      />
    </div>
  );
};
