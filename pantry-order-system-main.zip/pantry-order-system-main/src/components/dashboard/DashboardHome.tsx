
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Package, 
  ShoppingCart, 
  TrendingUp, 
  AlertTriangle,
  DollarSign,
  Users,
  Truck,
  Calendar
} from 'lucide-react';

const stats = [
  {
    title: 'Total Products',
    value: '247',
    change: '+12%',
    icon: Package,
    color: 'bg-blue-500'
  },
  {
    title: 'Pending Orders',
    value: '34',
    change: '+8%',
    icon: ShoppingCart,
    color: 'bg-green-500'
  },
  {
    title: 'Monthly Revenue',
    value: '$45,230',
    change: '+23%',
    icon: DollarSign,
    color: 'bg-purple-500'
  },
  {
    title: 'Low Stock Items',
    value: '8',
    change: '-2',
    icon: AlertTriangle,
    color: 'bg-orange-500'
  }
];

const recentOrders = [
  { id: 'ORD-001', customer: 'Sunshine Supermarket', amount: '$1,250', status: 'Processing', date: '2024-06-03' },
  { id: 'ORD-002', customer: 'Metro Wholesale', amount: '$850', status: 'Shipped', date: '2024-06-02' },
  { id: 'ORD-003', customer: 'Family Mart', amount: '$420', status: 'Delivered', date: '2024-06-01' },
  { id: 'ORD-004', customer: 'Corner Store', amount: '$320', status: 'Processing', date: '2024-06-01' },
];

const lowStockItems = [
  { name: 'Sugar (50kg bags)', current: 5, minimum: 10, status: 'Low' },
  { name: 'Cooking Oil (20L)', current: 8, minimum: 15, status: 'Low' },
  { name: 'Laundry Soap', current: 12, minimum: 20, status: 'Low' },
];

export const DashboardHome = ({ user }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'Processing':
        return 'bg-yellow-100 text-yellow-800';
      case 'Shipped':
        return 'bg-blue-100 text-blue-800';
      case 'Delivered':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                    <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                    <p className="text-sm text-green-600 mt-1">{stat.change} from last month</p>
                  </div>
                  <div className={`${stat.color} p-3 rounded-full`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Orders */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <ShoppingCart className="w-5 h-5 mr-2" />
              Recent Orders
            </CardTitle>
            <CardDescription>Latest customer orders</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentOrders.map((order) => (
                <div key={order.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium text-gray-900">{order.id}</p>
                    <p className="text-sm text-gray-600">{order.customer}</p>
                    <p className="text-xs text-gray-500">{order.date}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-gray-900">{order.amount}</p>
                    <Badge className={getStatusColor(order.status)}>
                      {order.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Low Stock Alert */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-orange-600">
              <AlertTriangle className="w-5 h-5 mr-2" />
              Low Stock Alert
            </CardTitle>
            <CardDescription>Items that need restocking</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {lowStockItems.map((item, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-orange-50 rounded-lg border border-orange-200">
                  <div>
                    <p className="font-medium text-gray-900">{item.name}</p>
                    <p className="text-sm text-gray-600">
                      Current: {item.current} | Min: {item.minimum}
                    </p>
                  </div>
                  <Badge className="bg-orange-100 text-orange-800">
                    {item.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      {(user.role === 'Admin' || user.role === 'Clerk') && (
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Common tasks for your role</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-blue-50 rounded-lg cursor-pointer hover:bg-blue-100 transition-colors">
                <Package className="w-8 h-8 text-blue-600 mb-2" />
                <h3 className="font-medium text-gray-900">Add New Product</h3>
                <p className="text-sm text-gray-600">Add items to inventory</p>
              </div>
              <div className="p-4 bg-green-50 rounded-lg cursor-pointer hover:bg-green-100 transition-colors">
                <ShoppingCart className="w-8 h-8 text-green-600 mb-2" />
                <h3 className="font-medium text-gray-900">New Order</h3>
                <p className="text-sm text-gray-600">Create customer order</p>
              </div>
              <div className="p-4 bg-purple-50 rounded-lg cursor-pointer hover:bg-purple-100 transition-colors">
                <TrendingUp className="w-8 h-8 text-purple-600 mb-2" />
                <h3 className="font-medium text-gray-900">Update Stock</h3>
                <p className="text-sm text-gray-600">Adjust inventory levels</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
