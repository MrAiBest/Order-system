import React, { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { DashboardHome } from './DashboardHome';
import { InventoryView } from '@/components/inventory/InventoryView';
import { OrdersView } from '@/components/orders/OrdersView';
import { DeliveryView } from '@/components/delivery/DeliveryView';
import { BillsView } from '@/components/bills/BillsView';
import { ClientsView } from '@/components/clients/ClientsView';
import { EmployeesView } from '@/components/employees/EmployeesView';
import { AnalyticsView } from '@/components/analytics/AnalyticsView';
import { DaybookView } from '@/components/daybook/DaybookView';
import { UserManagement } from '@/components/admin/UserManagement';
import { useDataStore } from '@/hooks/useDataStore';
import { BookOpen } from 'lucide-react';

interface DashboardProps {
  user: any;
  onLogout: () => void;
}

export const Dashboard = ({ user, onLogout }: DashboardProps) => {
  const [activeView, setActiveView] = useState('home');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  
  const {
    inventory,
    addProduct,
    restockProduct,
    orders,
    addOrder,
    updateOrderStatus,
    bills,
    addBill,
    updateBillStatus,
    clients,
    addClient,
    employees,
    addEmployee,
    updateEmployee,
    deliveries,
    updateDeliveryStatus,
    daybook,
    getDaybookByDate,
    getDaybookByCategory,
    getAnalyticsData
  } = useDataStore();

  const renderActiveView = () => {
    switch (activeView) {
      case 'home':
        return (
          <DashboardHome 
            user={user}
          />
        );
      case 'inventory':
        return (
          <InventoryView
            user={user}
            inventoryData={inventory}
            onAddProduct={(product) => addProduct(product, user.id, user.name)}
            onRestockProduct={(id, quantity) => restockProduct(id, quantity, user.id, user.name)}
          />
        );
      case 'orders':
        return (
          <OrdersView
            user={user}
            ordersData={orders}
            inventoryData={inventory}
            onAddOrder={(order) => addOrder(order, user.id, user.name)}
            onUpdateOrderStatus={(id, status) => updateOrderStatus(id, status, user.id, user.name)}
          />
        );
      case 'delivery':
        return (
          <DeliveryView
            user={user}
            orders={orders}
            deliveries={deliveries}
            onUpdateDeliveryStatus={(orderId, status, deliveryPerson, notes, returnReason, damageDescription) => 
              updateDeliveryStatus(orderId, status, deliveryPerson, notes, returnReason, damageDescription, user.id, user.name)
            }
          />
        );
      case 'bills':
        return (
          <BillsView
            user={user}
            billsData={bills}
            onAddBill={(bill) => addBill(bill, user.id, user.name)}
            onUpdateBillStatus={(id, status, paidDate) => updateBillStatus(id, status, paidDate, user.id, user.name)}
          />
        );
      case 'clients':
        return (
          <ClientsView
            user={user}
            clientsData={clients}
            onAddClient={(client) => addClient(client, user.id, user.name)}
          />
        );
      case 'employees':
        return (
          <EmployeesView
            user={user}
            employeesData={employees}
            onAddEmployee={(employee) => addEmployee(employee, user.id, user.name)}
            onUpdateEmployee={(id, updates) => updateEmployee(id, updates, user.id, user.name)}
          />
        );
      case 'analytics':
        return <AnalyticsView user={user} />;
      case 'daybook':
        // Only Admin and Manager can access daybook
        if (!['Admin', 'Manager'].includes(user.role)) {
          return (
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <BookOpen className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Access Restricted</h3>
                <p className="text-gray-600">You don't have permission to view the daybook.</p>
              </div>
            </div>
          );
        }
        return (
          <DaybookView
            user={user}
            daybook={daybook}
            getDaybookByDate={getDaybookByDate}
            getDaybookByCategory={getDaybookByCategory}
          />
        );
      case 'admin':
        return <UserManagement user={user} />;
      default:
        return <DashboardHome user={user} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex w-full">
      <Sidebar
        user={user}
        activeView={activeView}
        setActiveView={setActiveView}
        isOpen={sidebarOpen}
        setIsOpen={setSidebarOpen}
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          user={user} 
          onLogout={onLogout}
          toggleSidebar={() => setSidebarOpen(!sidebarOpen)}
        />
        
        <main className="flex-1 overflow-auto p-6">
          {renderActiveView()}
        </main>
      </div>
    </div>
  );
};
