
import React from 'react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { 
  Home, 
  Package, 
  ShoppingCart, 
  Receipt, 
  BarChart3,
  Building2,
  ChevronLeft,
  ChevronRight,
  Users,
  UserCheck,
  Truck,
  BookOpen,
  Shield
} from 'lucide-react';

const menuItems = [
  { id: 'home', label: 'Dashboard', icon: Home, roles: ['Admin', 'Manager', 'Clerk', 'Salesperson', 'Driver', 'Delivery Worker'] },
  { id: 'inventory', label: 'Inventory', icon: Package, roles: ['Admin', 'Manager', 'Clerk', 'Salesperson'] },
  { id: 'orders', label: 'Orders', icon: ShoppingCart, roles: ['Admin', 'Manager', 'Clerk', 'Salesperson', 'Driver', 'Delivery Worker'] },
  { id: 'delivery', label: 'Delivery', icon: Truck, roles: ['Driver', 'Delivery Worker', 'Admin', 'Manager'] },
  { id: 'clients', label: 'Clients', icon: Users, roles: ['Admin', 'Manager', 'Clerk', 'Salesperson'] },
  { id: 'employees', label: 'Employees', icon: UserCheck, roles: ['Admin', 'Manager'] },
  { id: 'bills', label: 'Bills', icon: Receipt, roles: ['Admin', 'Manager'] },
  { id: 'analytics', label: 'Analytics', icon: BarChart3, roles: ['Admin', 'Manager'] },
  { id: 'daybook', label: 'Daybook', icon: BookOpen, roles: ['Admin', 'Manager'] },
  { id: 'admin', label: 'Admin Panel', icon: Shield, roles: ['Admin'] },
];

export const Sidebar = ({ user, activeView, setActiveView, isOpen, setIsOpen }) => {
  const filteredMenuItems = menuItems.filter(item => 
    item.roles.includes(user.role)
  );

  return (
    <div className={cn(
      "bg-white shadow-lg transition-all duration-300 flex flex-col",
      isOpen ? "w-64" : "w-16"
    )}>
      <div className="flex items-center justify-between p-4 border-b">
        {isOpen && (
          <div className="flex items-center space-x-2">
            <Building2 className="w-8 h-8 text-blue-600" />
            <span className="font-bold text-lg text-gray-900">WholesaleManager</span>
          </div>
        )}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsOpen(!isOpen)}
          className="p-2"
        >
          {isOpen ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        </Button>
      </div>

      <nav className="flex-1 p-4">
        <div className="space-y-2">
          {filteredMenuItems.map((item) => {
            const Icon = item.icon;
            return (
              <Button
                key={item.id}
                variant={activeView === item.id ? "secondary" : "ghost"}
                className={cn(
                  "w-full justify-start",
                  !isOpen && "px-2",
                  activeView === item.id && "bg-blue-50 text-blue-700 border-r-2 border-blue-600"
                )}
                onClick={() => setActiveView(item.id)}
              >
                <Icon className={cn("w-5 h-5", isOpen && "mr-3")} />
                {isOpen && <span>{item.label}</span>}
              </Button>
            );
          })}
        </div>
      </nav>

      {isOpen && (
        <div className="p-4 border-t bg-gray-50">
          <div className="text-sm text-gray-600">
            <div className="font-medium">{user.name}</div>
            <div className="text-blue-600">{user.role}</div>
          </div>
        </div>
      )}
    </div>
  );
};
