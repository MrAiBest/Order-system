
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { LogOut, Menu, Bell } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useNotifications } from '@/hooks/useNotifications';
import { NotificationPanel } from '@/components/notifications/NotificationPanel';

export const Header = ({ user, onLogout, toggleSidebar }) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const { unreadCount } = useNotifications();

  const handleNotificationClick = () => {
    console.log('Notifications clicked');
    setShowNotifications(true);
  };

  const handleLogoutClick = () => {
    console.log('User logging out:', user.name);
    if (confirm('Are you sure you want to logout?')) {
      onLogout();
    }
  };

  return (
    <>
      <header className="bg-white shadow-sm border-b px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={toggleSidebar} className="lg:hidden">
              <Menu className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-xl font-semibold text-gray-900">Welcome back, {user.name}</h1>
              <p className="text-sm text-gray-600">Manage your wholesale operations</p>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              size="sm" 
              className="relative"
              onClick={handleNotificationClick}
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <Badge className="absolute -top-2 -right-2 w-5 h-5 text-xs bg-red-500 border-white">
                  {unreadCount}
                </Badge>
              )}
            </Button>
            
            <div className="flex items-center space-x-2">
              <div className="text-right">
                <div className="text-sm font-medium text-gray-900">{user.name}</div>
                <div className="text-xs text-gray-600">{user.role}</div>
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleLogoutClick}
                className="text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <NotificationPanel 
        isOpen={showNotifications}
        onClose={() => setShowNotifications(false)}
      />
    </>
  );
};
