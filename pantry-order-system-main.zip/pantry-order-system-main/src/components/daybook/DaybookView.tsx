
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  BookOpen, 
  Search, 
  Calendar,
  Filter,
  Package,
  ShoppingCart,
  Receipt,
  Users,
  UserCheck,
  Truck
} from 'lucide-react';

interface DaybookViewProps {
  user: any;
  daybook: any[];
  getDaybookByDate: (date: string) => any[];
  getDaybookByCategory: (category: string) => any[];
}

export const DaybookView = ({ user, daybook, getDaybookByDate, getDaybookByCategory }: DaybookViewProps) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  // Debug: Log daybook entries
  console.log('Daybook entries:', daybook);
  console.log('Total daybook entries:', daybook.length);

  const getIcon = (category: string) => {
    switch (category) {
      case 'order':
        return <ShoppingCart className="w-4 h-4 text-blue-600" />;
      case 'inventory':
        return <Package className="w-4 h-4 text-green-600" />;
      case 'bill':
        return <Receipt className="w-4 h-4 text-purple-600" />;
      case 'client':
        return <Users className="w-4 h-4 text-orange-600" />;
      case 'employee':
        return <UserCheck className="w-4 h-4 text-indigo-600" />;
      case 'delivery':
        return <Truck className="w-4 h-4 text-teal-600" />;
      default:
        return <BookOpen className="w-4 h-4 text-gray-600" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'order':
        return 'bg-blue-100 text-blue-800';
      case 'inventory':
        return 'bg-green-100 text-green-800';
      case 'bill':
        return 'bg-purple-100 text-purple-800';
      case 'client':
        return 'bg-orange-100 text-orange-800';
      case 'employee':
        return 'bg-indigo-100 text-indigo-800';
      case 'delivery':
        return 'bg-teal-100 text-teal-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleString();
  };

  // Filter daybook entries
  let filteredEntries = daybook;

  if (selectedDate) {
    filteredEntries = getDaybookByDate(selectedDate);
  }

  if (selectedCategory !== 'all') {
    filteredEntries = filteredEntries.filter(entry => entry.category === selectedCategory);
  }

  if (searchTerm) {
    filteredEntries = filteredEntries.filter(entry =>
      entry.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.userName.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }

  const categories = ['all', 'order', 'inventory', 'bill', 'client', 'employee', 'delivery'];

  // Permission check - All users can view daybook, but only certain roles see all entries
  const canViewAllEntries = ['Admin', 'Manager'].includes(user.role);
  const userEntries = canViewAllEntries ? filteredEntries : filteredEntries.filter(entry => entry.userId === user.id);

  console.log('Filtered entries:', userEntries);
  console.log('Can view all entries:', canViewAllEntries);
  console.log('User role:', user.role);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Daybook</h2>
          <p className="text-gray-600">Complete log of all business activities</p>
        </div>
        <div className="flex items-center space-x-2 mt-4 sm:mt-0">
          <Badge variant="outline" className="bg-blue-50 text-blue-700">
            {canViewAllEntries ? 'All Activities' : 'My Activities'}
          </Badge>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search activities..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <div className="flex gap-2">
              <Input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-auto"
              />
              
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="flex h-10 w-auto rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
              >
                {categories.map(category => (
                  <option key={category} value={category}>
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {categories.slice(1).map(category => (
          <Card key={category}>
            <CardContent className="p-4">
              <div className="flex items-center">
                {getIcon(category)}
                <div className="ml-2">
                  <p className="text-xs font-medium text-gray-600 capitalize">{category}</p>
                  <p className="text-lg font-bold text-gray-900">
                    {(canViewAllEntries ? daybook : daybook.filter(e => e.userId === user.id))
                      .filter(entry => entry.category === category).length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Daybook Entries */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BookOpen className="w-5 h-5 mr-2" />
            Activity Log
          </CardTitle>
          <CardDescription>
            {userEntries.length} entries found
            {selectedDate && ` for ${new Date(selectedDate).toLocaleDateString()}`}
            {selectedCategory !== 'all' && ` in ${selectedCategory} category`}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-96">
            {userEntries.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <BookOpen className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                <p>No activities found</p>
                <p className="text-xs mt-1">Total daybook entries: {daybook.length}</p>
                <p className="text-xs">Your role: {user.role}</p>
                <p className="text-xs">Can view all: {canViewAllEntries ? 'Yes' : 'No'}</p>
              </div>
            ) : (
              <div className="space-y-4">
                {userEntries.map((entry) => (
                  <div
                    key={entry.id}
                    className="flex items-start space-x-4 p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex-shrink-0 mt-1">
                      {getIcon(entry.category)}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <p className="text-sm font-medium text-gray-900">
                          {entry.description}
                        </p>
                        <Badge className={getCategoryColor(entry.category)} variant="secondary">
                          {entry.category}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center justify-between text-sm text-gray-600">
                        <span>by {entry.userName}</span>
                        <span>{formatTime(entry.timestamp)}</span>
                      </div>
                      
                      {entry.details && (
                        <details className="mt-2">
                          <summary className="text-xs text-blue-600 cursor-pointer hover:text-blue-800">
                            View Details
                          </summary>
                          <pre className="mt-1 text-xs text-gray-600 bg-gray-100 p-2 rounded overflow-auto">
                            {JSON.stringify(entry.details, null, 2)}
                          </pre>
                        </details>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
};
